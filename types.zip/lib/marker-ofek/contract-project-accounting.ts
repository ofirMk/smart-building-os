/**
 * סיווג שורות כתב כמויות / חשבונאות פרויקט (מרקר אופק)
 */

export type MoContractLineKind = "original" | "extra_work" | "tenant_change"

export type MoTenantChangeStatus = "pending" | "approved"

/** פריטי ייחוס ממחירון "דקל" — מחירי ברירת מחדל לשינויי דיירים */
export type DekelReferenceItem = {
  code: string
  description: string
  unit: string
  unit_price: number
}

export const DEKEL_REFERENCE_PRICE_LIST: DekelReferenceItem[] = [
  {
    code: "DK-ELEC-01",
    description: "הזזת נקודת חשמל",
    unit: "יח׳",
    unit_price: 450,
  },
  {
    code: "DK-PLB-01",
    description: "הזזת נקודת מים / ניקוז",
    unit: "יח׳",
    unit_price: 620,
  },
  {
    code: "DK-AC-01",
    description: "הוספת נקודת מזגן (כולל חציבה בסיסית)",
    unit: "יח׳",
    unit_price: 1850,
  },
  {
    code: "DK-TILE-01",
    description: "החלפת ריצוף חדר רחצה — עבודה + חומר סטנדרטי",
    unit: "מ״ר",
    unit_price: 280,
  },
  {
    code: "DK-DOOR-01",
    description: "שדרוג דלת פנים + משקוף",
    unit: "יח׳",
    unit_price: 2200,
  },
  {
    code: "DK-KITCHEN-01",
    description: "הרחבת מטבח — עבודת נגרות בסיסית",
    unit: "רץ מ״",
    unit_price: 950,
  },
]

export function normalizeContractLineKind(row: {
  line_kind?: string | null
  is_change_order?: boolean | null
}): MoContractLineKind {
  const k = row.line_kind
  if (k === "tenant_change" || k === "extra_work" || k === "original") {
    return k
  }
  return row.is_change_order ? "extra_work" : "original"
}

export function normalizeTenantStatus(
  raw: string | null | undefined
): MoTenantChangeStatus | null {
  if (raw === "pending" || raw === "approved") return raw
  return null
}
