import { MarkerOfekWorkspaceLayout } from "@/components/marker-ofek/workspace/marker-ofek-workspace-layout"

export default function MarkerOfekLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <MarkerOfekWorkspaceLayout>{children}</MarkerOfekWorkspaceLayout>
}
