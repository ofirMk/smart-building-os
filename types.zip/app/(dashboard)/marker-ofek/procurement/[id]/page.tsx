"use client"

import Link from "next/link"
import { useParams } from "next/navigation"
import * as React from "react"
import {
  AlertTriangle,
  ArrowRight,
  Building2,
  ClipboardCheck,
  Loader2,
  Package,
  Truck,
} from "lucide-react"

import {
  MoContextCommentButton,
  useMoCommentPresence,
} from "@/components/marker-ofek/mo-context-comment"
import { buttonVariants } from "@/components/ui/button-variants"
import { createSupabaseBrowserClient } from "@/lib/supabase/browser"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { cn } from "@/lib/utils"

type ProjectEmbed = { name: string; internal_project_code: string }
type EntityEmbed = { name: string }

type PoLineRow = {
  id: string
  description: string
  quantity: number
  unit: string | null
  unit_price: number
  total_price: number
  created_at: string
}

type PoDetail = {
  id: string
  po_number: string
  status: string
  project_id: string
  supplier_id: string
  projects: ProjectEmbed | ProjectEmbed[] | null
  entities: EntityEmbed | EntityEmbed[] | null
  po_line_items: PoLineRow[] | PoLineRow[] | null
}

function embedOne<T>(x: T | T[] | null | undefined): T | null {
  if (x == null) return null
  return Array.isArray(x) ? (x[0] ?? null) : x
}

function embedMany<T>(x: T | T[] | null | undefined): T[] {
  if (x == null) return []
  return Array.isArray(x) ? x : [x]
}

function roundQty(n: number): number {
  return Math.round(n * 10000) / 10000
}

const qtyDisplay = new Intl.NumberFormat("he-IL", {
  minimumFractionDigits: 0,
  maximumFractionDigits: 4,
})

const currencyFormatter = new Intl.NumberFormat("he-IL", {
  style: "currency",
  currency: "ILS",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})

function canRecordGoodsReceipt(status: string): boolean {
  return status === "approved" || status === "sent" || status === "partial_receipt"
}

function poStatusLabel(s: string): string {
  const map: Record<string, string> = {
    draft: "טיוטה",
    approved: "אושרה",
    sent: "נשלחה לספק",
    partial_receipt: "קבלה חלקית",
    closed: "נסגרה",
  }
  return map[s] ?? s
}

export default function ProcurementPoDetailPage() {
  const params = useParams()
  const poId = typeof params.id === "string" ? params.id : ""

  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState<string | null>(null)
  const [po, setPo] = React.useState<PoDetail | null>(null)
  const [receivedByLine, setReceivedByLine] = React.useState<
    Record<string, number>
  >({})

  React.useEffect(() => {
    if (!poId) {
      setLoading(false)
      setError("מזהה הזמנה חסר")
      return
    }

    let cancelled = false

    async function load() {
      setLoading(true)
      setError(null)
      try {
        const supabase = createSupabaseBrowserClient()

        const { data: poRow, error: poErr } = await supabase
          .from("purchase_orders")
          .select(
            `
            id,
            po_number,
            status,
            project_id,
            supplier_id,
            projects ( name, internal_project_code ),
            entities ( name ),
            po_line_items (
              id,
              description,
              quantity,
              unit,
              unit_price,
              total_price,
              created_at
            )
          `
          )
          .eq("id", poId)
          .eq("is_deleted", false)
          .maybeSingle()

        if (poErr) throw poErr
        if (!poRow) {
          if (!cancelled) {
            setPo(null)
            setError("הזמנת הרכש לא נמצאה")
          }
          return
        }

        const p = poRow as PoDetail
        const { data: receipts, error: rErr } = await supabase
          .from("goods_receipts")
          .select("id")
          .eq("po_id", poId)

        if (rErr) throw rErr
        const receiptIds = (receipts ?? []).map((r) => r.id as string)

        const priorByLine: Record<string, number> = {}
        const lines = embedMany(p.po_line_items).sort(
          (a, b) =>
            new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
        )
        for (const li of lines) priorByLine[li.id] = 0

        if (receiptIds.length > 0) {
          const { data: gri, error: griErr } = await supabase
            .from("goods_receipt_items")
            .select("po_line_item_id, quantity_received")
            .in("goods_receipt_id", receiptIds)

          if (griErr) throw griErr
          for (const row of gri ?? []) {
            const lid = (row as { po_line_item_id: string }).po_line_item_id
            const q =
              Number((row as { quantity_received: number }).quantity_received) ||
              0
            priorByLine[lid] = (priorByLine[lid] ?? 0) + q
          }
        }

        if (!cancelled) {
          setPo(p)
          setReceivedByLine(priorByLine)
        }
      } catch (e) {
        if (!cancelled) {
          setPo(null)
          setError(
            e instanceof Error ? e.message : "שגיאה בטעינת פרטי ההזמנה"
          )
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    void load()
    return () => {
      cancelled = true
    }
  }, [poId])

  const poLineIdsForComments = React.useMemo(() => {
    if (!po) return []
    return embedMany(po.po_line_items).map((l) => l.id)
  }, [po])

  const { hasComment: poLineHasComment } = useMoCommentPresence(
    po?.project_id ?? null,
    "po_line",
    poLineIdsForComments
  )

  const poCommentProjectName = React.useMemo(() => {
    const p = po ? embedOne(po.projects) : null
    return p?.name ?? "פרויקט"
  }, [po])

  if (loading) {
    return (
      <div className="flex min-h-[40vh] flex-col items-center justify-center gap-3 text-muted-foreground">
        <Loader2 className="size-8 animate-spin" aria-hidden />
        <p className="text-sm">טוען הזמנה…</p>
      </div>
    )
  }

  if (error || !po) {
    return (
      <div className="mx-auto max-w-lg space-y-4 py-12 text-center">
        <p className="text-destructive">{error ?? "לא ניתן לטעון"}</p>
        <Link
          href="/marker-ofek/procurement"
          className={cn(buttonVariants({ variant: "outline" }))}
        >
          חזרה לרכש
        </Link>
      </div>
    )
  }

  const project = embedOne(po.projects)
  const supplier = embedOne(po.entities)
  const lines = embedMany(po.po_line_items).sort(
    (a, b) =>
      new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
  )

  const pendingLines = lines
    .map((li) => {
      const ordered = Number(li.quantity) || 0
      const got = receivedByLine[li.id] ?? 0
      const pending = Math.max(0, roundQty(ordered - got))
      return { li, ordered, got, pending }
    })
    .filter((x) => x.pending > 0)

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-6 px-2 pb-12 sm:px-0">
      <Link
        href="/marker-ofek/procurement"
        className="inline-flex w-fit items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowRight className="size-4 rotate-180" aria-hidden />
        חזרה לרכש וספקים
      </Link>

      <header className="rounded-2xl border border-border/70 bg-gradient-to-br from-slate-950/90 via-slate-900/85 to-emerald-950/30 p-5 shadow-md sm:p-7">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
          <div className="space-y-2">
            <p className="text-xs font-medium uppercase tracking-wider text-emerald-400/90">
              פרטי הזמנת רכש
            </p>
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
              {po.po_number}
            </h1>
            <span className="inline-flex rounded-md border border-white/20 bg-white/10 px-2 py-0.5 text-xs font-medium text-white">
              {poStatusLabel(po.status)}
            </span>
          </div>
          <div className="grid w-full gap-4 text-sm text-slate-200 sm:max-w-sm">
            <div className="flex items-start gap-3">
              <Building2 className="mt-0.5 size-4 shrink-0 text-emerald-400" aria-hidden />
              <div>
                <p className="text-xs text-slate-400">פרויקט</p>
                <p className="font-medium">{project?.name ?? "—"}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Truck className="mt-0.5 size-4 shrink-0 text-emerald-400" aria-hidden />
              <div>
                <p className="text-xs text-slate-400">ספק</p>
                <p className="font-medium">{supplier?.name ?? "—"}</p>
              </div>
            </div>
          </div>
        </div>
        {canRecordGoodsReceipt(po.status) ? (
          <div className="mt-6">
            <Link
              href={`/marker-ofek/procurement/receipt/${po.id}`}
              className={cn(
                buttonVariants({ size: "default" }),
                "w-full gap-2 bg-emerald-600 text-white hover:bg-emerald-500 sm:w-auto"
              )}
            >
              <ClipboardCheck className="size-4" aria-hidden />
              קליטת סחורה
            </Link>
          </div>
        ) : null}
      </header>

      {po.status === "partial_receipt" && pendingLines.length > 0 ? (
        <section
          className="rounded-2xl border border-amber-500/40 bg-amber-500/10 p-4 shadow-sm sm:p-5"
          role="region"
          aria-label="פריטים בחוסר"
        >
          <div className="mb-3 flex items-center gap-2 text-amber-900 dark:text-amber-100">
            <AlertTriangle className="size-5 shrink-0" aria-hidden />
            <h2 className="text-lg font-semibold">פריטים בחוסר (ממתינים לאספקה)</h2>
          </div>
          <p className="mb-4 text-sm text-muted-foreground">
            סיכום שורות שעדיין לא הושלמה קבלתן מול כמות בהזמנה.
          </p>
          <div className="hidden overflow-x-auto rounded-lg border border-border/50 md:block">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40 hover:bg-muted/40">
                  <TableHead className="w-11 px-0 text-center">
                    <span className="sr-only">הערות</span>
                  </TableHead>
                  <TableHead>תיאור</TableHead>
                  <TableHead className="text-end">הוזמן</TableHead>
                  <TableHead className="text-end">התקבל</TableHead>
                  <TableHead className="text-end">בחוסר</TableHead>
                  <TableHead className="text-end">שווי בחוסר (משוער)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingLines.map(({ li, ordered, got, pending }) => (
                  <TableRow key={li.id}>
                    <TableCell className="w-11 p-1 align-top">
                      <MoContextCommentButton
                        projectId={po.project_id}
                        projectName={poCommentProjectName}
                        contextType="po_line"
                        contextId={li.id}
                        contextLabel={`שורת רכש: ${li.description.slice(0, 48)}${li.description.length > 48 ? "…" : ""}`}
                        hasComment={poLineHasComment(li.id)}
                      />
                    </TableCell>
                    <TableCell className="max-w-[240px] font-medium">
                      {li.description}
                      {li.unit ? (
                        <span className="mt-0.5 block text-xs text-muted-foreground">
                          יחידה: {li.unit}
                        </span>
                      ) : null}
                    </TableCell>
                    <TableCell className="text-end tabular-nums">
                      {qtyDisplay.format(ordered)}
                    </TableCell>
                    <TableCell className="text-end tabular-nums">
                      {qtyDisplay.format(got)}
                    </TableCell>
                    <TableCell className="text-end font-semibold tabular-nums text-amber-800 dark:text-amber-300">
                      {qtyDisplay.format(pending)}
                    </TableCell>
                    <TableCell className="text-end tabular-nums">
                      {currencyFormatter.format(
                        pending * (Number(li.unit_price) || 0)
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <ul className="flex flex-col gap-3 md:hidden">
            {pendingLines.map(({ li, ordered, got, pending }) => (
              <li
                key={li.id}
                className="rounded-xl border border-amber-500/30 bg-card/80 p-4"
              >
                <p className="font-medium leading-snug">{li.description}</p>
                <dl className="mt-3 grid grid-cols-2 gap-x-2 gap-y-1 text-xs">
                  <dt className="text-muted-foreground">הוזמן</dt>
                  <dd className="text-end tabular-nums">{qtyDisplay.format(ordered)}</dd>
                  <dt className="text-muted-foreground">התקבל</dt>
                  <dd className="text-end tabular-nums">{qtyDisplay.format(got)}</dd>
                  <dt className="font-medium text-amber-800 dark:text-amber-300">
                    בחוסר
                  </dt>
                  <dd className="text-end font-semibold tabular-nums text-amber-800 dark:text-amber-300">
                    {qtyDisplay.format(pending)}
                  </dd>
                  <dt className="text-muted-foreground">שווי בחוסר</dt>
                  <dd className="text-end tabular-nums">
                    {currencyFormatter.format(
                      pending * (Number(li.unit_price) || 0)
                    )}
                  </dd>
                </dl>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="rounded-2xl border border-border/60 bg-card/80 shadow-sm">
        <div className="flex items-center gap-2 border-b border-border/60 px-4 py-4 sm:px-6">
          <Package className="size-5 text-muted-foreground" aria-hidden />
          <h2 className="text-lg font-semibold">כל שורות ההזמנה</h2>
        </div>
        <div className="overflow-x-auto p-2 sm:p-4">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/40 hover:bg-muted/40">
                <TableHead className="w-11 px-0 text-center">
                  <span className="sr-only">הערות</span>
                </TableHead>
                <TableHead>תיאור</TableHead>
                <TableHead className="text-end">כמות</TableHead>
                <TableHead className="text-end">התקבל</TableHead>
                <TableHead className="text-end">יתרה</TableHead>
                <TableHead className="text-end">מחיר יחידה</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {lines.map((li) => {
                const ordered = Number(li.quantity) || 0
                const got = receivedByLine[li.id] ?? 0
                const rem = Math.max(0, roundQty(ordered - got))
                return (
                  <TableRow key={li.id}>
                    <TableCell className="w-11 p-1 align-top">
                      <MoContextCommentButton
                        projectId={po.project_id}
                        projectName={poCommentProjectName}
                        contextType="po_line"
                        contextId={li.id}
                        contextLabel={`שורת רכש: ${li.description.slice(0, 48)}${li.description.length > 48 ? "…" : ""}`}
                        hasComment={poLineHasComment(li.id)}
                      />
                    </TableCell>
                    <TableCell className="max-w-[200px]">{li.description}</TableCell>
                    <TableCell className="text-end tabular-nums">
                      {qtyDisplay.format(ordered)}
                    </TableCell>
                    <TableCell className="text-end tabular-nums">
                      {qtyDisplay.format(got)}
                    </TableCell>
                    <TableCell
                      className={cn(
                        "text-end tabular-nums",
                        rem > 0 &&
                          "font-medium text-amber-700 dark:text-amber-400"
                      )}
                    >
                      {qtyDisplay.format(rem)}
                    </TableCell>
                    <TableCell className="text-end tabular-nums">
                      {currencyFormatter.format(Number(li.unit_price) || 0)}
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </div>
      </section>
    </div>
  )
}
