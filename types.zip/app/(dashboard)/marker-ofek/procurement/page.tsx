"use client"

import Link from "next/link"
import * as React from "react"
import {
  AlertTriangle,
  ArrowRight,
  ClipboardCheck,
  Loader2,
  Package,
  Plus,
  Scale,
  ShoppingCart,
} from "lucide-react"

import { buttonVariants } from "@/components/ui/button-variants"
import { createSupabaseBrowserClient } from "@/lib/supabase/browser"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { cn } from "@/lib/utils"

type PoListRow = {
  id: string
  po_number: string
  order_date: string
  status: string
  total_amount: number
  projects:
    | { name: string; internal_project_code: string }
    | { name: string; internal_project_code: string }[]
    | null
  entities: { name: string } | { name: string }[] | null
}

function embedOne<T>(x: T | T[] | null | undefined): T | null {
  if (x == null) return null
  return Array.isArray(x) ? (x[0] ?? null) : x
}

const currencyFormatter = new Intl.NumberFormat("he-IL", {
  style: "currency",
  currency: "ILS",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})

const dateFormatter = new Intl.DateTimeFormat("he-IL", {
  dateStyle: "short",
})

/** הזמנות שניתן לקלוט אליהן סחורה (אושרה / נשלחה / קבלה חלקית) */
function canRecordGoodsReceipt(status: string): boolean {
  return status === "approved" || status === "sent" || status === "partial_receipt"
}

function poStatusLabel(s: string): string {
  const map: Record<string, string> = {
    draft: "טיוטה",
    approved: "אושרה",
    sent: "נשלחה לספק",
    partial_receipt: "קבלה חלקית",
    closed: "נסגרה",
  }
  return map[s] ?? s
}

export default function MarkerOfekProcurementPage() {
  const [rows, setRows] = React.useState<PoListRow[]>([])
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState<string | null>(null)
  const [shortageNotePoIds, setShortageNotePoIds] = React.useState<Set<string>>(
    () => new Set()
  )

  React.useEffect(() => {
    let cancelled = false
    async function load() {
      setLoading(true)
      setError(null)
      try {
        const supabase = createSupabaseBrowserClient()
        const { data, error: qError } = await supabase
          .from("purchase_orders")
          .select(
            `
            id,
            po_number,
            order_date,
            status,
            total_amount,
            projects ( name, internal_project_code ),
            entities ( name )
          `
          )
          .eq("is_deleted", false)
          .order("created_at", { ascending: false })
          .limit(50)

        if (qError) throw qError
        const list = (data as PoListRow[]) ?? []
        if (!cancelled) setRows(list)

        const ids = list.map((r) => r.id)
        if (ids.length === 0) {
          if (!cancelled) setShortageNotePoIds(new Set())
          return
        }

        const { data: grWithNotes, error: grErr } = await supabase
          .from("goods_receipts")
          .select("po_id, shortage_notes")
          .in("po_id", ids)
          .not("shortage_notes", "is", null)

        if (grErr) {
          if (
            !grErr.message?.includes("shortage_notes") &&
            !grErr.message?.includes("column")
          ) {
            console.warn("[procurement] shortage_notes query", grErr.message)
          }
          if (!cancelled) setShortageNotePoIds(new Set())
          return
        }

        const noteSet = new Set<string>()
        for (const row of grWithNotes ?? []) {
          const r = row as { po_id: string; shortage_notes: string | null }
          if (r.shortage_notes?.trim()) noteSet.add(r.po_id)
        }
        if (!cancelled) setShortageNotePoIds(noteSet)
      } catch (e) {
        if (!cancelled) {
          setRows([])
          setShortageNotePoIds(new Set())
          setError(e instanceof Error ? e.message : String(e))
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    void load()
    return () => {
      cancelled = true
    }
  }, [])

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-8 pb-10">
      <Link
        href="/marker-ofek"
        className="inline-flex w-fit items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowRight className="size-4 rotate-180" aria-hidden />
        חזרה ללוח הבקרה
      </Link>

      <div className="relative overflow-hidden rounded-2xl border border-border/70 bg-gradient-to-br from-slate-950/90 via-slate-900/80 to-emerald-950/35 p-6 shadow-lg shadow-black/20 md:p-8">
        <div
          className="pointer-events-none absolute -start-24 -top-24 size-72 rounded-full bg-emerald-500/10 blur-3xl"
          aria-hidden
        />
        <div className="relative flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div className="flex min-w-0 flex-1 items-start gap-4">
            <div className="flex size-12 shrink-0 items-center justify-center rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-300">
              <ShoppingCart className="size-6" aria-hidden />
            </div>
            <div className="min-w-0 space-y-2">
              <p className="text-xs font-medium uppercase tracking-wider text-emerald-400/90">
                מרקר אופק
              </p>
              <h1 className="text-pretty text-2xl font-bold tracking-tight text-white md:text-3xl">
                ניהול רכש וספקים
              </h1>
              <p className="max-w-2xl text-sm leading-relaxed text-slate-300">
                מעקב אחר הזמנות רכש, ספקים וקבלות סחורה מול פרויקטים.
              </p>
            </div>
          </div>
          <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row sm:items-center">
            <Link
              href="/marker-ofek/procurement/aging"
              className={cn(
                buttonVariants({ size: "lg", variant: "outline" }),
                "w-full shrink-0 gap-2 border-amber-500/40 text-amber-950 hover:bg-amber-500/10 dark:text-amber-100 sm:w-auto"
              )}
            >
              <Scale className="size-4" aria-hidden />
              גילון ספקים
            </Link>
            <Link
              href="/marker-ofek/procurement/new"
              className={cn(
                buttonVariants({ size: "lg" }),
                "w-full shrink-0 gap-2 bg-emerald-600 text-white hover:bg-emerald-500 sm:w-auto"
              )}
            >
              <Plus className="size-4" aria-hidden />
              יצירת הזמנת רכש חדשה
            </Link>
          </div>
        </div>
      </div>

      {!loading &&
      !error &&
      rows.some((r) => r.status === "partial_receipt") ? (
        <Alert variant="warning" className="border-amber-500/45">
          <AlertTriangle className="size-4" aria-hidden />
          <AlertTitle>משלוח חלקי — דורש מעקב</AlertTitle>
          <AlertDescription>
            יש הזמנות במצב קבלה חלקית. בדקו את &quot;פריטים בחוסר&quot; בפרטי ההזמנה
            והשלימו קליטה או עדכנו חשבונות ספק בגילון.
          </AlertDescription>
        </Alert>
      ) : null}

      <section className="rounded-2xl border border-border/60 bg-card/80 shadow-sm backdrop-blur-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/60 px-4 py-4 md:px-6">
          <div className="flex items-center gap-2 text-foreground">
            <Package className="size-5 text-muted-foreground" aria-hidden />
            <h2 className="text-lg font-semibold tracking-tight">
              הזמנות רכש אחרונות
            </h2>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 py-16 text-muted-foreground">
            <Loader2 className="size-5 animate-spin" aria-hidden />
            <span>טוען הזמנות…</span>
          </div>
        ) : error ? (
          <div className="px-4 py-8 text-center text-sm text-destructive md:px-6">
            שגיאה בטעינת ההזמנות: {error}
            <p className="mt-2 text-xs text-muted-foreground">
              ודאו שהרצתם את{" "}
              <code className="rounded bg-muted px-1">marker_ofek_procurement.sql</code>{" "}
              ב-Supabase.
            </p>
          </div>
        ) : rows.length === 0 ? (
          <div className="px-4 py-14 text-center text-sm text-muted-foreground md:px-6">
            <p>אין עדיין הזמנות רכש במערכת.</p>
            <Link
              href="/marker-ofek/procurement/new"
              className="mt-4 inline-flex text-emerald-600 underline-offset-4 hover:underline dark:text-emerald-400"
            >
              ליצירת הזמנה ראשונה
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto px-2 pb-4 md:px-4">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40 hover:bg-muted/40">
                  <TableHead className="text-start">מספר הזמנה</TableHead>
                  <TableHead className="text-start">פרויקט</TableHead>
                  <TableHead className="text-start">ספק</TableHead>
                  <TableHead className="text-start">תאריך</TableHead>
                  <TableHead className="text-start">סטטוס</TableHead>
                  <TableHead className="text-end">סכום כולל</TableHead>
                  <TableHead className="w-[1%] whitespace-nowrap text-start">
                    פעולות
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((row) => {
                  const project = embedOne(row.projects)
                  const supplier = embedOne(row.entities)
                  return (
                    <TableRow key={row.id}>
                      <TableCell className="font-mono text-sm font-medium">
                        <span className="inline-flex flex-wrap items-center gap-2">
                          <Link
                            href={`/marker-ofek/procurement/${row.id}`}
                            className="text-emerald-700 underline-offset-4 hover:underline dark:text-emerald-400"
                          >
                            {row.po_number}
                          </Link>
                          {(row.status === "partial_receipt" ||
                            shortageNotePoIds.has(row.id)) ? (
                            <span
                              className="inline-flex items-center gap-1 rounded-md border border-amber-500/50 bg-amber-500/12 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-amber-900 dark:text-amber-100"
                              title="משלוח חלקי או נרשמו הערות חוסר בקבלה"
                            >
                              <AlertTriangle className="size-3" aria-hidden />
                              חלקי
                            </span>
                          ) : null}
                        </span>
                      </TableCell>
                      <TableCell className="max-w-[200px]">
                        <span className="truncate">{project?.name ?? "—"}</span>
                        {project?.internal_project_code ? (
                          <span className="mt-0.5 block font-mono text-xs text-muted-foreground">
                            {project.internal_project_code}
                          </span>
                        ) : null}
                      </TableCell>
                      <TableCell className="max-w-[180px] truncate">
                        {supplier?.name ?? "—"}
                      </TableCell>
                      <TableCell className="whitespace-nowrap tabular-nums">
                        {row.order_date
                          ? dateFormatter.format(new Date(row.order_date))
                          : "—"}
                      </TableCell>
                      <TableCell>
                        <span className="inline-flex rounded-md border border-border/60 bg-muted/40 px-2 py-0.5 text-xs font-medium">
                          {poStatusLabel(row.status)}
                        </span>
                      </TableCell>
                      <TableCell className="text-end font-medium tabular-nums">
                        {currencyFormatter.format(Number(row.total_amount) || 0)}
                      </TableCell>
                      <TableCell className="align-top">
                        {canRecordGoodsReceipt(row.status) ? (
                          <Link
                            href={`/marker-ofek/procurement/receipt/${row.id}`}
                            className={cn(
                              buttonVariants({ size: "sm", variant: "outline" }),
                              "gap-1.5 whitespace-nowrap border-emerald-500/40 text-emerald-700 hover:bg-emerald-500/10 dark:text-emerald-400"
                            )}
                          >
                            <ClipboardCheck className="size-3.5" aria-hidden />
                            קליטת סחורה
                          </Link>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </section>
    </div>
  )
}
