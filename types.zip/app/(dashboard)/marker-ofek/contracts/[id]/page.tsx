"use client"

import Link from "next/link"
import { useParams } from "next/navigation"
import * as React from "react"
import {
  ArrowRight,
  Building2,
  Calculator,
  FileSpreadsheet,
  Home,
  Loader2,
  Plus,
  Printer,
  Receipt,
  Users,
  Wallet,
  FileText,
} from "lucide-react"
import { toast } from "sonner"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DEKEL_REFERENCE_PRICE_LIST,
  type MoContractLineKind,
  type MoTenantChangeStatus,
  normalizeContractLineKind,
  normalizeTenantStatus,
} from "@/lib/marker-ofek/contract-project-accounting"
import { createSupabaseBrowserClient } from "@/lib/supabase/browser"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { cn } from "@/lib/utils"
import type { CompanyProfile, MoChangeOrderStatus } from "@/types/marker-ofek"
import {
  MoContextCommentButton,
  useMoCommentPresence,
} from "@/components/marker-ofek/mo-context-comment"
import { IssueClientInvoiceDialog } from "@/components/marker-ofek/issue-client-invoice-dialog"
import { DualPaneLayout } from "@/components/marker-ofek/workspace/dual-pane-layout"
import { useMarkerOfekWorkspace } from "@/components/marker-ofek/workspace/marker-ofek-workspace-context"

type EntityEmbed = {
  name: string
  legal_id: string | null
  address: string | null
  deductions_file_number: string | null
}

type ContractRowRaw = {
  id: string
  project_id: string
  entity_id: string
  total_amount: number | null
  retention_pct: number
  insurance_pct: number
  agreement_type: string | null
  contract_type: string
  status: string
  projects:
    | { name: string; internal_project_code: string; address: string | null }
    | { name: string; internal_project_code: string; address: string | null }[]
    | null
  entities: EntityEmbed | EntityEmbed[] | null
}

type ContractRow = Omit<ContractRowRaw, "projects" | "entities"> & {
  projects: {
    name: string
    internal_project_code: string
    address: string | null
  } | null
  entities: EntityEmbed | null
}

function embedOne<T>(x: T | T[] | null | undefined): T | null {
  if (x == null) return null
  return Array.isArray(x) ? (x[0] ?? null) : x
}

type LineItemRow = {
  id: string
  section_number: string
  description: string
  unit: string | null
  quantity: number | null
  unit_price: number | null
  is_change_order: boolean
  change_order_desc: string | null
  line_kind: MoContractLineKind
  apartment_number: string | null
  tenant_change_status: MoTenantChangeStatus | null
  change_order_status: MoChangeOrderStatus | null
  tenant_floor: string | null
  /** טרם נשמר ל-contract_line_items */
  isPending?: boolean
}

const currencyFormatter = new Intl.NumberFormat("he-IL", {
  style: "currency",
  currency: "ILS",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})

function lineBaseAmount(line: LineItemRow): number {
  const q = Number(line.quantity) || 0
  const p = Number(line.unit_price) || 0
  return q * p
}

function normalizeChangeOrderStatus(
  lineKind: MoContractLineKind,
  raw: unknown
): MoChangeOrderStatus | null {
  if (lineKind !== "extra_work") return null
  const s = typeof raw === "string" ? raw : null
  if (s === "pending" || s === "approved" || s === "rejected") return s
  return "approved"
}

/** חריג שלא מאושר לא נכנס לחישובי תשלום / מצטבר */
function lineCountsTowardBilling(line: LineItemRow): boolean {
  if (line.line_kind === "extra_work" && line.change_order_status !== "approved") {
    return false
  }
  return true
}

function mapDbLineToRow(row: Record<string, unknown>): LineItemRow {
  const lk = normalizeContractLineKind({
    line_kind: row.line_kind as string | null | undefined,
    is_change_order: row.is_change_order as boolean | null | undefined,
  })
  const ts = normalizeTenantStatus(
    row.tenant_change_status as string | null | undefined
  )
  return {
    id: String(row.id),
    section_number: String(row.section_number ?? ""),
    description: String(row.description ?? ""),
    unit: (row.unit as string | null) ?? null,
    quantity:
      row.quantity === null || row.quantity === undefined
        ? null
        : Number(row.quantity),
    unit_price:
      row.unit_price === null || row.unit_price === undefined
        ? null
        : Number(row.unit_price),
    is_change_order: Boolean(row.is_change_order),
    change_order_desc: (row.change_order_desc as string | null) ?? null,
    line_kind: lk,
    apartment_number: (row.apartment_number as string | null) ?? null,
    tenant_change_status: lk === "tenant_change" ? ts ?? "pending" : null,
    change_order_status: normalizeChangeOrderStatus(
      lk,
      row.change_order_status
    ),
    tenant_floor: (row.tenant_floor as string | null) ?? null,
    isPending: false,
  }
}

function parsePct(raw: string): number {
  const n = parseFloat(String(raw).replace(",", "."))
  if (!Number.isFinite(n)) return 0
  return Math.min(100, Math.max(0, n))
}

function roundMoney(n: number): number {
  return Math.round(n * 100) / 100
}

function remapPctKeys(
  pctMap: Record<string, string>,
  tempToReal: Map<string, string>
): Record<string, string> {
  const next = { ...pctMap }
  for (const [temp, real] of tempToReal) {
    if (Object.prototype.hasOwnProperty.call(next, temp)) {
      next[real] = next[temp]!
      delete next[temp]
    }
  }
  return next
}

const VAT_RATE = 0.17

const qtyPrintFormatter = new Intl.NumberFormat("he-IL", {
  minimumFractionDigits: 0,
  maximumFractionDigits: 3,
})

function buildPrintLineDescription(line: LineItemRow): string {
  let s = line.description
  if (line.line_kind === "extra_work") {
    const st =
      line.change_order_status === "approved"
        ? "מאושר"
        : line.change_order_status === "rejected"
          ? "נדחה"
          : "ממתין"
    s += ` [חריג · ${st}]`
  }
  if (line.line_kind === "tenant_change") {
    const fl = line.tenant_floor?.trim()
    s += ` [קומה ${fl || "—"} · דירה ${line.apartment_number?.trim() || "—"} · ${
      line.tenant_change_status === "approved" ? "מאושר" : "ממתין"
    }]`
  }
  if (line.isPending) s += " (טיוטה)"
  return s
}

export default function MarkerOfekContractDetailPage() {
  const params = useParams()
  const id = typeof params.id === "string" ? params.id : ""

  const [contract, setContract] = React.useState<ContractRow | null>(null)
  const [lines, setLines] = React.useState<LineItemRow[]>([])
  const [submittedPct, setSubmittedPct] = React.useState<Record<string, string>>(
    {}
  )
  const [approvedPct, setApprovedPct] = React.useState<Record<string, string>>({})
  const approvedLockedRef = React.useRef<Record<string, boolean>>({})

  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState<string | null>(null)
  const [savingPartialAccount, setSavingPartialAccount] = React.useState(false)
  const [lastPartialAccountNumber, setLastPartialAccountNumber] = React.useState<
    number | null
  >(null)
  const [priorContractPaymentsSum, setPriorContractPaymentsSum] =
    React.useState(0)
  const [priorProjectPaymentsSum, setPriorProjectPaymentsSum] =
    React.useState(0)
  const [previousSameContractCumulative, setPreviousSameContractCumulative] =
    React.useState(0)
  const [tenantFloorFilter, setTenantFloorFilter] = React.useState("")
  const [tenantAptFilter, setTenantAptFilter] = React.useState("")
  const [companyProfile, setCompanyProfile] = React.useState<CompanyProfile | null>(
    null
  )
  const [issueInvoiceOpen, setIssueInvoiceOpen] = React.useState(false)
  const { setContextProjectId } = useMarkerOfekWorkspace()
  const [dualSplit, setDualSplit] = React.useState(false)

  React.useEffect(() => {
    if (contract?.project_id) setContextProjectId(contract.project_id)
  }, [contract?.project_id, setContextProjectId])

  const boqReferencePanel = React.useMemo(
    () => (
      <div className="space-y-2 text-xs leading-relaxed">
        <p className="font-semibold text-foreground">כתב כמויות — תצוגת עזר</p>
        <p className="text-[11px] text-muted-foreground">
          סיכום שורות לעיון לצד עדכון אחוזים או הפקת חשבון חלקי.
        </p>
        <ul className="max-h-[min(24rem,55vh)] space-y-2 overflow-y-auto pe-1">
          {lines.map((l) => {
            const base = roundMoney(
              (Number(l.quantity) || 0) * (Number(l.unit_price) || 0)
            )
            return (
              <li
                key={l.id}
                className="rounded-md border border-border/40 bg-background/50 px-2 py-1.5"
              >
                <div className="flex justify-between gap-2">
                  <span className="font-mono text-violet-600">
                    {l.section_number}
                  </span>
                  <span className="tabular-nums text-muted-foreground">
                    {currencyFormatter.format(base)}
                  </span>
                </div>
                <p className="mt-0.5 line-clamp-2 text-[11px] text-foreground">
                  {l.description}
                </p>
              </li>
            )
          })}
        </ul>
      </div>
    ),
    [lines]
  )

  const contractLineIdsForComments = React.useMemo(
    () => lines.filter((l) => !l.isPending).map((l) => l.id),
    [lines]
  )
  const { hasComment: lineHasComment } = useMoCommentPresence(
    contract?.project_id ?? null,
    "contract_item",
    contractLineIdsForComments
  )
  const commentProjectName = contract?.projects?.name ?? "פרויקט"

  function updateLine(lineId: string, patch: Partial<LineItemRow>) {
    setLines((prev) =>
      prev.map((l) => (l.id === lineId ? { ...l, ...patch } : l))
    )
  }

  function handleSubmittedChange(lineId: string, value: string) {
    setSubmittedPct((prev) => ({ ...prev, [lineId]: value }))
    if (!approvedLockedRef.current[lineId]) {
      setApprovedPct((prev) => ({ ...prev, [lineId]: value }))
    }
  }

  function handleApprovedChange(lineId: string, value: string) {
    approvedLockedRef.current[lineId] = true
    setApprovedPct((prev) => ({ ...prev, [lineId]: value }))
  }

  function addChangeOrderRow() {
    const nid = `pending-co-${crypto.randomUUID()}`
    setLines((prev) => [
      ...prev,
      {
        id: nid,
        section_number: "CO",
        description: "",
        unit: "יח",
        quantity: null,
        unit_price: null,
        is_change_order: true,
        change_order_desc: "",
        line_kind: "extra_work",
        apartment_number: null,
        tenant_change_status: null,
        change_order_status: "pending",
        tenant_floor: null,
        isPending: true,
      },
    ])
    setSubmittedPct((p) => ({ ...p, [nid]: "" }))
    setApprovedPct((p) => ({ ...p, [nid]: "" }))
  }

  function addTenantChangeRow() {
    const nid = `pending-tenant-${crypto.randomUUID()}`
    setLines((prev) => [
      ...prev,
      {
        id: nid,
        section_number: "דייר",
        description: "",
        unit: "יח׳",
        quantity: null,
        unit_price: null,
        is_change_order: false,
        change_order_desc: null,
        line_kind: "tenant_change",
        apartment_number: "",
        tenant_change_status: "pending",
        change_order_status: null,
        tenant_floor: "",
        isPending: true,
      },
    ])
    setSubmittedPct((p) => ({ ...p, [nid]: "" }))
    setApprovedPct((p) => ({ ...p, [nid]: "" }))
  }

  function addTenantChangeFromDekel(item: (typeof DEKEL_REFERENCE_PRICE_LIST)[0]) {
    const nid = `pending-tenant-${crypto.randomUUID()}`
    setLines((prev) => [
      ...prev,
      {
        id: nid,
        section_number: "דייר",
        description: item.description,
        unit: item.unit,
        quantity: 1,
        unit_price: item.unit_price,
        is_change_order: false,
        change_order_desc: null,
        line_kind: "tenant_change",
        apartment_number: "",
        tenant_change_status: "pending",
        change_order_status: null,
        tenant_floor: "",
        isPending: true,
      },
    ])
    setSubmittedPct((p) => ({ ...p, [nid]: "" }))
    setApprovedPct((p) => ({ ...p, [nid]: "" }))
  }

  React.useEffect(() => {
    if (!id) {
      setLoading(false)
      setError("מזהה חוזה חסר")
      return
    }

    let cancelled = false

    async function load() {
      setLoading(true)
      setError(null)
      try {
        const supabase = createSupabaseBrowserClient()

        const [cRes, profileRes] = await Promise.all([
          supabase
            .from("contracts")
            .select(
              `
            id,
            project_id,
            entity_id,
            total_amount,
            retention_pct,
            insurance_pct,
            agreement_type,
            contract_type,
            status,
            projects ( name, internal_project_code, address ),
            entities ( name, legal_id, address, deductions_file_number )
          `
            )
            .eq("id", id)
            .eq("is_deleted", false)
            .maybeSingle(),
          supabase
            .from("company_profile")
            .select("*")
            .order("created_at", { ascending: true })
            .limit(1)
            .maybeSingle(),
        ])

        const cRow = cRes.data
        const cErr = cRes.error

        if (cErr) throw cErr
        if (profileRes.error) {
          console.warn(
            "[Marker Ofek] company_profile",
            profileRes.error.message
          )
        }
        if (!cRow) {
          if (!cancelled) {
            setContract(null)
            setLines([])
            setCompanyProfile(null)
            setError("החוזה לא נמצא")
          }
          return
        }

        const { data: li, error: liErr } = await supabase
          .from("contract_line_items")
          .select(
            "id, section_number, description, unit, quantity, unit_price, is_change_order, change_order_desc, line_kind, apartment_number, tenant_change_status, change_order_status, tenant_floor"
          )
          .eq("contract_id", id)
          .order("created_at", { ascending: true })

        if (liErr) throw liErr

        if (!cancelled) {
          const cr = cRow as ContractRowRaw
          setContract({
            ...cr,
            projects: embedOne(cr.projects),
            entities: embedOne(cr.entities),
          })
          if (profileRes.data) {
            setCompanyProfile(profileRes.data as CompanyProfile)
          } else {
            setCompanyProfile(null)
          }

          const mapped: LineItemRow[] = (li ?? []).map((row) =>
            mapDbLineToRow(row as Record<string, unknown>)
          )
          setLines(mapped)

          const subInit: Record<string, string> = {}
          const appInit: Record<string, string> = {}
          for (const row of mapped) {
            subInit[row.id] = ""
            appInit[row.id] = ""
          }

          const projectId = cr.project_id
          const { data: siblingContracts } = await supabase
            .from("contracts")
            .select("id")
            .eq("project_id", projectId)
            .eq("is_deleted", false)
          const siblingIds = (siblingContracts ?? [])
            .map((c) => (c as { id: string }).id)
            .filter(Boolean)
          const projectContractIds =
            siblingIds.length > 0 ? siblingIds : [id]

          if (projectContractIds.length > 0) {
            const { data: lastProjPa } = await supabase
              .from("partial_accounts")
              .select("id")
              .in("contract_id", projectContractIds)
              .eq("is_deleted", false)
              .in("status", ["submitted", "approved", "paid"])
              .order("created_at", { ascending: false })
              .limit(1)
              .maybeSingle()

            if (lastProjPa?.id) {
              const { data: paliRows } = await supabase
                .from("partial_account_line_items")
                .select("contract_line_item_id, approved_percentage")
                .eq("partial_account_id", lastProjPa.id)

              const lineIdSet = new Set(mapped.map((l) => l.id))
              for (const pr of paliRows ?? []) {
                const lid = (pr as { contract_line_item_id: string })
                  .contract_line_item_id
                if (lineIdSet.has(lid)) {
                  appInit[lid] = String(
                    Number(
                      (pr as { approved_percentage: number })
                        .approved_percentage
                    )
                  )
                }
              }
            }
          }

          const { data: pcRows } = await supabase
            .from("partial_accounts")
            .select("payment_due")
            .eq("contract_id", id)
            .eq("is_deleted", false)
            .in("status", ["submitted", "approved", "paid"])
          const pcSum = roundMoney(
            (pcRows ?? []).reduce(
              (s, r) => s + Number((r as { payment_due: number }).payment_due),
              0
            )
          )

          const { data: pprojRows } = await supabase
            .from("partial_accounts")
            .select("payment_due")
            .in("contract_id", projectContractIds)
            .eq("is_deleted", false)
            .in("status", ["submitted", "approved", "paid"])
          const ppSum = roundMoney(
            (pprojRows ?? []).reduce(
              (s, r) => s + Number((r as { payment_due: number }).payment_due),
              0
            )
          )

          const { data: lastSame } = await supabase
            .from("partial_accounts")
            .select("total_cumulative_amount")
            .eq("contract_id", id)
            .eq("is_deleted", false)
            .in("status", ["submitted", "approved", "paid"])
            .order("account_number", { ascending: false })
            .limit(1)
            .maybeSingle()
          const prevSame = Number(
            (lastSame as { total_cumulative_amount?: number } | null)
              ?.total_cumulative_amount
          )

          if (!cancelled) {
            setPriorContractPaymentsSum(pcSum)
            setPriorProjectPaymentsSum(ppSum)
            setPreviousSameContractCumulative(
              Number.isFinite(prevSame) ? roundMoney(prevSame) : 0
            )
            setSubmittedPct(subInit)
            setApprovedPct(appInit)
            approvedLockedRef.current = {}
          }
        }
      } catch (e) {
        if (!cancelled) {
          setContract(null)
          setLines([])
          setCompanyProfile(null)
          setError(e instanceof Error ? e.message : String(e))
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    void load()
    return () => {
      cancelled = true
    }
  }, [id])

  const totals = React.useMemo(() => {
    let totalSubmitted = 0
    let totalApproved = 0
    for (const line of lines) {
      if (!lineCountsTowardBilling(line)) continue
      const base = lineBaseAmount(line)
      const sub = parsePct(submittedPct[line.id] ?? "")
      const app = parsePct(approvedPct[line.id] ?? "")
      totalSubmitted += base * (sub / 100)
      totalApproved += base * (app / 100)
    }

    const retentionPct = Number(contract?.retention_pct) || 0
    const insurancePct = Number(contract?.insurance_pct) || 0
    const retentionAmount = totalApproved * (retentionPct / 100)
    const insuranceAmount = totalApproved * (insurancePct / 100)
    const finalPayout = totalApproved - retentionAmount - insuranceAmount

    return {
      totalSubmitted,
      totalApproved,
      retentionAmount,
      insuranceAmount,
      finalPayout,
      retentionPct,
      insurancePct,
    }
  }, [lines, submittedPct, approvedPct, contract])

  const printTotals = React.useMemo(() => {
    const totalBoqLineBases = lines.reduce((s, l) => s + lineBaseAmount(l), 0)
    const submittedWeightedPct =
      totalBoqLineBases > 0
        ? (totals.totalSubmitted / totalBoqLineBases) * 100
        : 0
    const approvedWeightedPct =
      totalBoqLineBases > 0
        ? (totals.totalApproved / totalBoqLineBases) * 100
        : 0
    const paymentBeforeVat = roundMoney(totals.finalPayout)
    const vatAmount = roundMoney(paymentBeforeVat * VAT_RATE)
    const grandTotal = roundMoney(paymentBeforeVat + vatAmount)
    return {
      totalBoqLineBases,
      submittedWeightedPct,
      approvedWeightedPct,
      paymentBeforeVat,
      vatAmount,
      grandTotal,
    }
  }, [lines, totals])

  const accountingSummary = React.useMemo(() => {
    const originalBase = roundMoney(
      lines
        .filter((l) => l.line_kind === "original")
        .reduce((s, l) => s + lineBaseAmount(l), 0)
    )
    const extraApprovedPartial = roundMoney(
      lines
        .filter(
          (l) =>
            l.line_kind === "extra_work" &&
            l.change_order_status === "approved"
        )
        .reduce((s, l) => {
          const base = lineBaseAmount(l)
          const app = parsePct(approvedPct[l.id] ?? "")
          return s + base * (app / 100)
        }, 0)
    )
    const tenantApproved = roundMoney(
      lines
        .filter(
          (l) =>
            l.line_kind === "tenant_change" &&
            l.tenant_change_status === "approved"
        )
        .reduce((s, l) => s + lineBaseAmount(l), 0)
    )
    const tenantPending = roundMoney(
      lines
        .filter(
          (l) =>
            l.line_kind === "tenant_change" &&
            l.tenant_change_status === "pending"
        )
        .reduce((s, l) => s + lineBaseAmount(l), 0)
    )
    const cumulativeExecution = roundMoney(
      originalBase + extraApprovedPartial + tenantApproved
    )
    return {
      originalBase,
      extraApprovedPartial,
      tenantApproved,
      tenantPending,
      cumulativeExecution,
    }
  }, [lines, approvedPct])

  const grandFinancialSummary = React.useMemo(() => {
    const approvedExtraFullBase = roundMoney(
      lines
        .filter(
          (l) =>
            l.line_kind === "extra_work" &&
            l.change_order_status === "approved"
        )
        .reduce((s, l) => s + lineBaseAmount(l), 0)
    )
    const originalBase = roundMoney(
      lines
        .filter((l) => l.line_kind === "original")
        .reduce((s, l) => s + lineBaseAmount(l), 0)
    )
    const tenantAppr = roundMoney(
      lines
        .filter(
          (l) =>
            l.line_kind === "tenant_change" &&
            l.tenant_change_status === "approved"
        )
        .reduce((s, l) => s + lineBaseAmount(l), 0)
    )
    const totalProjectScope = roundMoney(
      originalBase + approvedExtraFullBase + tenantAppr
    )
    const currentPaymentDueNet = roundMoney(
      Math.max(0, totals.finalPayout - priorContractPaymentsSum)
    )
    return {
      totalProjectScope,
      totalApprovedToDate: roundMoney(totals.totalApproved),
      priorPayments: priorContractPaymentsSum,
      currentPaymentDueNet,
    }
  }, [lines, totals, priorContractPaymentsSum])

  const tenantLinesFiltered = React.useMemo(() => {
    const base = lines.filter((l) => l.line_kind === "tenant_change")
    const f = tenantFloorFilter.trim().toLowerCase()
    const a = tenantAptFilter.trim().toLowerCase()
    return base.filter((l) => {
      if (f && !(l.tenant_floor ?? "").toLowerCase().includes(f)) {
        return false
      }
      if (a && !(l.apartment_number ?? "").toLowerCase().includes(a)) {
        return false
      }
      return true
    })
  }, [lines, tenantFloorFilter, tenantAptFilter])

  async function updateChangeOrderLineStatus(
    lineId: string,
    status: MoChangeOrderStatus
  ) {
    const supabase = createSupabaseBrowserClient()
    const { error } = await supabase
      .from("contract_line_items")
      .update({ change_order_status: status })
      .eq("id", lineId)
    if (error) {
      toast.error(error.message)
      return
    }
    setLines((prev) =>
      prev.map((l) =>
        l.id === lineId ? { ...l, change_order_status: status } : l
      )
    )
    toast.success("סטטוס הוראת השינוי עודכן")
  }

  async function persistTenantFloor(
    lineId: string,
    floor: string | null
  ) {
    const supabase = createSupabaseBrowserClient()
    const { error } = await supabase
      .from("contract_line_items")
      .update({ tenant_floor: floor?.trim() || null })
      .eq("id", lineId)
    if (error) toast.error(error.message)
  }

  async function updateTenantLineStatus(
    lineId: string,
    status: MoTenantChangeStatus
  ) {
    const supabase = createSupabaseBrowserClient()
    const { error } = await supabase
      .from("contract_line_items")
      .update({ tenant_change_status: status })
      .eq("id", lineId)
    if (error) {
      toast.error(error.message)
      return
    }
    setLines((prev) =>
      prev.map((l) =>
        l.id === lineId ? { ...l, tenant_change_status: status } : l
      )
    )
    toast.success("סטטוס שינוי דייר עודכן")
  }

  async function handleGeneratePartialAccount() {
    const pendingLines = lines.filter((l) => l.isPending)
    for (const pl of pendingLines) {
      if (pl.line_kind === "tenant_change") {
        if (!pl.apartment_number?.trim() || !pl.description.trim()) {
          toast.error(
            "בשינוי דייר: נא למלא מספר דירה ותיאור השינוי לפני ההפקה"
          )
          return
        }
        const q = Number(pl.quantity) || 0
        const up = Number(pl.unit_price) || 0
        if (q <= 0 || up < 0) {
          toast.error("בשינוי דייר: נא למלא כמות חיובית ומחיר יחידה")
          return
        }
      } else if (!pl.section_number.trim() || !pl.description.trim()) {
        toast.error("יש למלא מספר סעיף ותיאור בכל שורת חריג לפני ההפקה")
        return
      }
    }

    const supabase = createSupabaseBrowserClient()
    const tempToReal = new Map<string, string>()

    setSavingPartialAccount(true)

    try {
      for (const pl of pendingLines) {
        const q = Number(pl.quantity) || 0
        const up = Number(pl.unit_price) || 0
        const baseInsert = {
          contract_id: id,
          description: pl.description.trim(),
          unit: pl.unit?.trim() || null,
          quantity: q || null,
          unit_price: up || null,
        }
        const payload =
          pl.line_kind === "tenant_change"
            ? {
                ...baseInsert,
                section_number: pl.apartment_number?.trim() || "דירה",
                is_change_order: false,
                change_order_desc: null,
                line_kind: "tenant_change" as const,
                apartment_number: pl.apartment_number?.trim() || null,
                tenant_change_status: pl.tenant_change_status ?? "pending",
                tenant_floor: pl.tenant_floor?.trim() || null,
              }
            : {
                ...baseInsert,
                section_number: pl.section_number.trim(),
                is_change_order: true,
                change_order_desc: pl.change_order_desc?.trim() || null,
                line_kind: "extra_work" as const,
                apartment_number: null,
                tenant_change_status: null,
                change_order_status: pl.change_order_status ?? "pending",
              }

        const { data: inserted, error: insErr } = await supabase
          .from("contract_line_items")
          .insert(payload)
          .select("id")
          .single()

        if (insErr) throw insErr
        if (!inserted?.id) throw new Error("שמירת שורה נכשלה")
        tempToReal.set(pl.id, inserted.id)
      }

      let remappedSubmitted = remapPctKeys(submittedPct, tempToReal)
      let remappedApproved = remapPctKeys(approvedPct, tempToReal)
      for (const [temp, real] of tempToReal) {
        if (approvedLockedRef.current[temp]) {
          approvedLockedRef.current[real] = true
        }
        delete approvedLockedRef.current[temp]
      }

      const { data: liFresh, error: liFreshErr } = await supabase
        .from("contract_line_items")
        .select(
          "id, section_number, description, unit, quantity, unit_price, is_change_order, change_order_desc, line_kind, apartment_number, tenant_change_status, change_order_status, tenant_floor"
        )
        .eq("contract_id", id)
        .order("created_at", { ascending: true })

      if (liFreshErr) throw liFreshErr

      const fresh: LineItemRow[] = (liFresh ?? []).map((row) =>
        mapDbLineToRow(row as Record<string, unknown>)
      )

      const nextSubmitted: Record<string, string> = {}
      const nextApproved: Record<string, string> = {}
      for (const l of fresh) {
        nextSubmitted[l.id] = remappedSubmitted[l.id] ?? ""
        nextApproved[l.id] = remappedApproved[l.id] ?? ""
      }
      remappedSubmitted = nextSubmitted
      remappedApproved = nextApproved

      const withActivity = fresh
        .map((line) => {
          const base = lineBaseAmount(line)
          const s = parsePct(remappedSubmitted[line.id] ?? "")
          const a = parsePct(remappedApproved[line.id] ?? "")
          return {
            line,
            s,
            a,
            subAmt: roundMoney(base * (s / 100)),
            appAmt: roundMoney(base * (a / 100)),
          }
        })
        .filter(
          (x) =>
            (x.s > 0 || x.a > 0) && lineCountsTowardBilling(x.line)
        )

      const newContractTotal = fresh.reduce((s, l) => s + lineBaseAmount(l), 0)
      const { error: contractUpdErr } = await supabase
        .from("contracts")
        .update({ total_amount: roundMoney(newContractTotal) })
        .eq("id", id)
        .eq("is_deleted", false)
      if (contractUpdErr) throw contractUpdErr

      if (withActivity.length === 0) {
        setLines(fresh)
        setSubmittedPct(remappedSubmitted)
        setApprovedPct(remappedApproved)
        setContract((prev) =>
          prev
            ? { ...prev, total_amount: roundMoney(newContractTotal) }
            : prev
        )
        toast.error("יש להזין אחוז מוגש או מאושר גדול מ-0 בלפחות סעיף אחד")
        return
      }

      let totalSubmitted = 0
      let totalApproved = 0
      for (const l of fresh) {
        if (!lineCountsTowardBilling(l)) continue
        const base = lineBaseAmount(l)
        totalSubmitted +=
          base * (parsePct(remappedSubmitted[l.id] ?? "") / 100)
        totalApproved += base * (parsePct(remappedApproved[l.id] ?? "") / 100)
      }

      const retentionPct = Number(contract?.retention_pct) || 0
      const insurancePct = Number(contract?.insurance_pct) || 0
      const retentionAmount = totalApproved * (retentionPct / 100)
      const insuranceAmount = totalApproved * (insurancePct / 100)
      const finalPayout = totalApproved - retentionAmount - insuranceAmount

      const snapshotPayload = {
        generated_at: new Date().toISOString(),
        contract_id: id,
        project_id: contract?.project_id ?? null,
        lines: fresh.map((l) => ({
          id: l.id,
          section_number: l.section_number,
          description: l.description,
          line_kind: l.line_kind,
          change_order_status: l.change_order_status,
          base_amount: lineBaseAmount(l),
          submitted_pct: remappedSubmitted[l.id] ?? "",
          approved_pct: remappedApproved[l.id] ?? "",
        })),
        totals: {
          total_submitted: roundMoney(totalSubmitted),
          total_approved: roundMoney(totalApproved),
          retention_deduction: roundMoney(retentionAmount),
          insurance_deduction: roundMoney(insuranceAmount),
          payment_due: roundMoney(finalPayout),
        },
      }

      const { data: partialRow, error: paErr } = await supabase
        .from("partial_accounts")
        .insert({
          contract_id: id,
          status: "submitted",
          total_cumulative_amount: roundMoney(totalApproved),
          retention_deduction: roundMoney(retentionAmount),
          insurance_deduction: roundMoney(insuranceAmount),
          payment_due: roundMoney(finalPayout),
          snapshot_payload: snapshotPayload,
          previous_cumulative_approved: previousSameContractCumulative,
          project_id: contract?.project_id ?? null,
        })
        .select("id, account_number")
        .single()

      if (paErr) throw paErr
      if (!partialRow?.id) throw new Error("לא נשמר מזהה חשבון חלקי")
      const acctNum = (partialRow as { account_number?: number }).account_number
      if (typeof acctNum === "number") setLastPartialAccountNumber(acctNum)

      const lineInserts = withActivity.map(
        ({ line, s, a, subAmt, appAmt }) => ({
          partial_account_id: partialRow.id,
          contract_line_item_id: line.id,
          execution_percentage: a,
          cumulative_amount: appAmt,
          submitted_percentage: s,
          submitted_amount: subAmt,
          approved_percentage: a,
          approved_amount: appAmt,
        })
      )

      const { error: liErr } = await supabase
        .from("partial_account_line_items")
        .insert(lineInserts)

      if (liErr) {
        await supabase.from("partial_accounts").delete().eq("id", partialRow.id)
        throw liErr
      }

      setLines(fresh)
      setSubmittedPct(remappedSubmitted)
      setApprovedPct(remappedApproved)
      setContract((prev) =>
        prev
          ? { ...prev, total_amount: roundMoney(newContractTotal) }
          : prev
      )

      setPreviousSameContractCumulative(roundMoney(totalApproved))

      const { data: pcAfter } = await supabase
        .from("partial_accounts")
        .select("payment_due")
        .eq("contract_id", id)
        .eq("is_deleted", false)
        .in("status", ["submitted", "approved", "paid"])
      setPriorContractPaymentsSum(
        roundMoney(
          (pcAfter ?? []).reduce(
            (s, r) => s + Number((r as { payment_due: number }).payment_due),
            0
          )
        )
      )

      const pid = contract?.project_id
      if (pid) {
        const { data: sibs } = await supabase
          .from("contracts")
          .select("id")
          .eq("project_id", pid)
          .eq("is_deleted", false)
        const sibIds = (sibs ?? []).map((c) => (c as { id: string }).id)
        if (sibIds.length > 0) {
          const { data: ppAfter } = await supabase
            .from("partial_accounts")
            .select("payment_due")
            .in("contract_id", sibIds)
            .eq("is_deleted", false)
            .in("status", ["submitted", "approved", "paid"])
          setPriorProjectPaymentsSum(
            roundMoney(
              (ppAfter ?? []).reduce(
                (s, r) =>
                  s + Number((r as { payment_due: number }).payment_due),
                0
              )
            )
          )
        }
      }

      toast.success("חשבון חלקי הופק ונשמר בהצלחה!")
    } catch (e) {
      const msg =
        e instanceof Error
          ? e.message
          : typeof e === "object" &&
              e !== null &&
              "message" in e &&
              typeof (e as { message: unknown }).message === "string"
            ? (e as { message: string }).message
            : String(e)
      console.error("[Marker Ofek] שמירת חשבון חלקי נכשלה", e)
      toast.error(`שמירת החשבון החלקי נכשלה: ${msg}`)
    } finally {
      setSavingPartialAccount(false)
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-[40vh] flex-col items-center justify-center gap-3 text-muted-foreground">
        <Loader2 className="size-8 animate-spin" aria-hidden />
        <p className="text-sm">טוען פרטי חוזה…</p>
      </div>
    )
  }

  if (error || !contract) {
    return (
      <div className="mx-auto max-w-lg space-y-4 py-12 text-center">
        <p className="text-destructive">{error ?? "לא ניתן לטעון את החוזה"}</p>
        <Button
          variant="outline"
          render={<Link href="/marker-ofek/contracts" />}
        >
          חזרה לרשימת חוזים
        </Button>
      </div>
    )
  }

  const projectName = contract.projects?.name ?? "—"
  const projectAddress = contract.projects?.address?.trim() || "—"
  const entityName = contract.entities?.name ?? "—"
  const clientAddress = contract.entities?.address?.trim() || "—"
  const clientLegalId = contract.entities?.legal_id?.trim() || "—"
  const issuer = companyProfile
  const contractTotal =
    contract.total_amount != null
      ? currencyFormatter.format(Number(contract.total_amount))
      : "—"
  const contractTotalNum = Number(contract.total_amount) || 0
  const agreementLabel = contract.agreement_type?.trim() || "פאושלי"

  const issueDateLabel = new Intl.DateTimeFormat("he-IL", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date())

  function handlePrintPdf() {
    window.print()
  }

  return (
    <>
      <DualPaneLayout
        split={dualSplit}
        onSplitChange={setDualSplit}
        referenceTitle="כתב כמויות (BoQ)"
        reference={boqReferencePanel}
      >
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-8 pb-12 print:hidden">
        <Link
          href="/marker-ofek/contracts"
          className="inline-flex w-fit items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowRight className="size-4 rotate-180" aria-hidden />
          חזרה לרשימת חוזים
        </Link>

        <header className="relative overflow-hidden rounded-2xl border border-border/70 bg-gradient-to-br from-slate-950/95 via-slate-900/90 to-cyan-950/50 p-6 shadow-lg md:p-8">
          <div
            className="pointer-events-none absolute -start-20 -top-20 size-64 rounded-full bg-cyan-500/15 blur-3xl"
            aria-hidden
          />
          <div className="relative grid gap-6 md:grid-cols-3">
            <div className="flex items-start gap-3 md:col-span-1">
              <div className="flex size-11 shrink-0 items-center justify-center rounded-xl border border-cyan-500/35 bg-cyan-500/10 text-cyan-300">
                <Building2 className="size-5" aria-hidden />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-medium text-cyan-400/90">שם פרויקט</p>
                <p className="text-lg font-semibold text-white">{projectName}</p>
                {contract.projects?.internal_project_code ? (
                  <p className="mt-0.5 font-mono text-xs text-slate-400">
                    {contract.projects.internal_project_code}
                  </p>
                ) : null}
              </div>
            </div>
            <div className="flex items-start gap-3 md:col-span-1">
              <div className="flex size-11 shrink-0 items-center justify-center rounded-xl border border-violet-500/35 bg-violet-500/10 text-violet-300">
                <Users className="size-5" aria-hidden />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-medium text-violet-300/90">שם ישות</p>
                <p className="text-lg font-semibold text-white">{entityName}</p>
              </div>
            </div>
            <div className="flex items-start gap-3 md:col-span-1">
              <div className="flex size-11 shrink-0 items-center justify-center rounded-xl border border-amber-500/35 bg-amber-500/10 text-amber-200">
                <Receipt className="size-5" aria-hidden />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-medium text-amber-200/90">
                  סכום חוזה כולל
                </p>
                <p className="text-xl font-bold tabular-nums text-white">
                  {contractTotal}
                </p>
              </div>
            </div>
          </div>
        </header>

        <Card className="border-border/70 shadow-sm">
          <CardHeader className="border-b border-border/60 bg-muted/20">
            <div className="flex items-start gap-3">
              <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-sky-500/15 text-sky-700 dark:text-sky-400">
                <Wallet className="size-5" aria-hidden />
              </div>
              <div className="min-w-0 space-y-1">
                <CardTitle>מצב חשבונאי — סיכום כלכלי לפרויקט</CardTitle>
                <CardDescription>
                  פירוט לפי מקור הסעיף: חוזה חתום, חריגים (לפי אחוז מאושר בחשבון
                  חלקי), ושינויי דיירים. ניכויי עכבון וביטוח חלים על סה״כ מאושר
                  בשורות החשבון החלקי.
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6 pt-6">
            <div className="rounded-lg border border-dashed border-border/70 bg-muted/25 p-4">
              <p className="text-xs font-semibold text-muted-foreground">
                מצטבר קודם והיסטוריית חשבונות
              </p>
              <div className="mt-3 grid gap-3 text-sm sm:grid-cols-3">
                <div>
                  <p className="text-xs text-muted-foreground">
                    מצטבר מאושר קודם (חוזה זה)
                  </p>
                  <p className="font-semibold tabular-nums">
                    {currencyFormatter.format(previousSameContractCumulative)}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">
                    תשלומים בחשבונות (חוזה)
                  </p>
                  <p className="font-semibold tabular-nums">
                    {currencyFormatter.format(priorContractPaymentsSum)}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">
                    תשלומים בפרויקט (כל החוזים)
                  </p>
                  <p className="font-semibold tabular-nums">
                    {currencyFormatter.format(priorProjectPaymentsSum)}
                  </p>
                </div>
              </div>
              <p className="mt-2 text-[11px] text-muted-foreground">
                אחוזי מאושר בטבלה למטה נטענו מהחשבון החלקי האחרון בפרויקט
                (הוגש/מאושר/שולם), לפי שורות המתאימות לחוזה זה.
              </p>
            </div>
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="space-y-3 rounded-xl border border-sky-500/25 bg-sky-500/[0.04] p-4 dark:bg-sky-500/10">
                <p className="text-xs font-semibold text-sky-800 dark:text-sky-300">
                  היקפי עבודה לפי מקור
                </p>
                <dl className="space-y-2 text-sm">
                  <div className="flex justify-between gap-4 border-b border-border/40 pb-2">
                    <dt className="text-muted-foreground">סה״כ חוזה מקורי</dt>
                    <dd className="font-semibold tabular-nums">
                      {currencyFormatter.format(accountingSummary.originalBase)}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-4 border-b border-border/40 pb-2">
                    <dt className="text-muted-foreground">
                      סה״כ חריגים מאושרים
                    </dt>
                    <dd className="font-semibold tabular-nums text-amber-800 dark:text-amber-300">
                      {currencyFormatter.format(
                        accountingSummary.extraApprovedPartial
                      )}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-4 border-b border-border/40 pb-2">
                    <dt className="text-muted-foreground">
                      סה״כ שינויי דיירים (מאושר)
                    </dt>
                    <dd className="font-semibold tabular-nums text-violet-800 dark:text-violet-300">
                      {currencyFormatter.format(
                        accountingSummary.tenantApproved
                      )}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-4 pt-1">
                    <dt className="text-muted-foreground">
                      שינויי דיירים בהמתנה
                    </dt>
                    <dd className="tabular-nums text-muted-foreground">
                      {currencyFormatter.format(
                        accountingSummary.tenantPending
                      )}
                    </dd>
                  </div>
                </dl>
              </div>
              <div className="space-y-3 rounded-xl border border-emerald-500/25 bg-emerald-500/[0.04] p-4 dark:bg-emerald-500/10">
                <p className="text-xs font-semibold text-emerald-800 dark:text-emerald-300">
                  מצטבר לביצוע וניכויים
                </p>
                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-muted-foreground">
                      סה״כ מצטבר לביצוע (מקורי + חריגים מאושרים + דיירים מאושרים)
                    </p>
                    <p className="text-xl font-bold tabular-nums text-emerald-700 dark:text-emerald-400">
                      {currencyFormatter.format(
                        accountingSummary.cumulativeExecution
                      )}
                    </p>
                  </div>
                  <div className="grid gap-3 border-t border-border/50 pt-3 sm:grid-cols-2">
                    <div>
                      <p className="text-xs text-muted-foreground">
                        עכבון ({totals.retentionPct}% על מאושר)
                      </p>
                      <p className="font-semibold tabular-nums text-amber-800 dark:text-amber-300">
                        −{currencyFormatter.format(totals.retentionAmount)}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">
                        ביטוח ({totals.insurancePct}% על מאושר)
                      </p>
                      <p className="font-semibold tabular-nums text-amber-800 dark:text-amber-300">
                        −{currencyFormatter.format(totals.insuranceAmount)}
                      </p>
                    </div>
                  </div>
                  <div className="border-t border-border/50 pt-3">
                    <p className="text-xs text-muted-foreground">
                      לתשלום לפני מע״מ (אחרי ניכויים, לפי מאושר כללי)
                    </p>
                    <p className="text-lg font-bold tabular-nums">
                      {currencyFormatter.format(totals.finalPayout)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/70 shadow-sm">
          <CardHeader className="border-b border-border/60">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="size-5 text-muted-foreground" />
              <div>
                <CardTitle>כתב כמויות ושינויים</CardTitle>
                <CardDescription>
                  שלושה מסכים: סעיפי חוזה חתומים, עבודות נוספות שלא ב־BoQ המקורי,
                  ושדרוגי דיירים לפי מחירון ייחוס.
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <Tabs defaultValue="boq" className="w-full gap-4">
              <TabsList className="mb-2 h-auto w-full flex-wrap justify-start gap-1 bg-muted/60 p-1 sm:w-auto">
                <TabsTrigger value="boq" className="gap-1.5 text-xs sm:text-sm">
                  סעיפי חוזה
                </TabsTrigger>
                <TabsTrigger
                  value="extra"
                  className="gap-1.5 border border-transparent text-xs data-active:border-amber-500/30 data-active:bg-amber-500/10 sm:text-sm"
                >
                  עבודות נוספות / חריגים
                </TabsTrigger>
                <TabsTrigger
                  value="tenant"
                  className="gap-1.5 border border-transparent text-xs data-active:border-violet-500/30 data-active:bg-violet-500/10 sm:text-sm"
                >
                  שינויי דיירים
                </TabsTrigger>
              </TabsList>

              <TabsContent value="boq" className="mt-0">
                {lines.filter((l) => l.line_kind === "original").length ===
                0 ? (
                  <p className="py-8 text-center text-sm text-muted-foreground">
                    אין סעיפי חוזה מקוריים. ניתן להוסיף ביצירת חוזה או לסווג שורות
                    ב-SQL.
                  </p>
                ) : (
                  <div className="overflow-x-auto rounded-lg border border-sky-500/20 bg-sky-500/[0.02]">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-sky-500/10 hover:bg-sky-500/10">
                          <TableHead className="w-11 px-0 text-center">
                            <span className="sr-only">הערות</span>
                          </TableHead>
                          <TableHead className="w-10" />
                          <TableHead>סעיף</TableHead>
                          <TableHead>תיאור</TableHead>
                          <TableHead>יחידה</TableHead>
                          <TableHead className="text-end">כמות</TableHead>
                          <TableHead className="text-end">מחיר יחידה</TableHead>
                          <TableHead className="text-end">סכום שורה</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {lines
                          .filter((l) => l.line_kind === "original")
                          .map((line) => (
                            <TableRow key={line.id}>
                              <TableCell className="w-11 p-1 align-top">
                                <MoContextCommentButton
                                  projectId={contract.project_id}
                                  projectName={commentProjectName}
                                  contextType="contract_item"
                                  contextId={line.isPending ? null : line.id}
                                  contextLabel={`סעיף ${line.section_number}`}
                                  hasComment={lineHasComment(line.id)}
                                  disabled={line.isPending}
                                />
                              </TableCell>
                              <TableCell className="align-top">
                                <Badge
                                  variant="secondary"
                                  className="text-[10px] whitespace-nowrap"
                                >
                                  חוזה
                                </Badge>
                              </TableCell>
                              <TableCell className="align-top font-mono text-sm">
                                {line.section_number}
                              </TableCell>
                              <TableCell className="max-w-xs align-top">
                                {line.description}
                              </TableCell>
                              <TableCell className="align-top">
                                {line.unit ?? "—"}
                              </TableCell>
                              <TableCell className="align-top text-end tabular-nums">
                                {line.quantity ?? "—"}
                              </TableCell>
                              <TableCell className="align-top text-end tabular-nums">
                                {line.unit_price != null
                                  ? currencyFormatter.format(
                                      Number(line.unit_price)
                                    )
                                  : "—"}
                              </TableCell>
                              <TableCell className="text-end font-medium tabular-nums">
                                {currencyFormatter.format(
                                  lineBaseAmount(line)
                                )}
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="extra" className="mt-0 space-y-4">
                <p className="text-xs text-muted-foreground">
                  פריטים שנוספו במהלך הביצוע ואינם חלק מכתב הכמויות החתום.
                </p>
                {lines.filter((l) => l.line_kind === "extra_work").length ===
                  0 && !lines.some((l) => l.isPending && l.line_kind === "extra_work") ? (
                  <p className="py-6 text-center text-sm text-muted-foreground">
                    אין עדיין חריגים. הוסיפו שורה חדשה למטה.
                  </p>
                ) : null}
                <div className="overflow-x-auto rounded-lg border border-amber-500/25 bg-amber-500/[0.03]">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-amber-500/15 hover:bg-amber-500/15">
                        <TableHead className="w-11 px-0 text-center">
                          <span className="sr-only">הערות</span>
                        </TableHead>
                        <TableHead className="w-10" />
                        <TableHead>סעיף</TableHead>
                        <TableHead>תיאור / הוראת שינוי</TableHead>
                        <TableHead>יחידה</TableHead>
                        <TableHead className="text-end">כמות</TableHead>
                        <TableHead className="text-end">מחיר יחידה</TableHead>
                        <TableHead className="min-w-[9rem]">סטטוס אישור</TableHead>
                        <TableHead className="text-end">סכום שורה</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {lines
                        .filter((l) => l.line_kind === "extra_work")
                        .map((line) => (
                          <TableRow
                            key={line.id}
                            className={cn(
                              "bg-amber-500/[0.04] dark:bg-amber-500/10",
                              line.change_order_status === "rejected" &&
                                "opacity-60"
                            )}
                          >
                            <TableCell className="w-11 p-1 align-top">
                              <MoContextCommentButton
                                projectId={contract.project_id}
                                projectName={commentProjectName}
                                contextType="contract_item"
                                contextId={line.isPending ? null : line.id}
                                contextLabel={`חריג ${line.section_number}`}
                                hasComment={lineHasComment(line.id)}
                                disabled={line.isPending}
                              />
                            </TableCell>
                            <TableCell className="align-top">
                              <Badge
                                variant="outline"
                                className="whitespace-nowrap border-amber-500/50 text-[10px] text-amber-800 dark:text-amber-300"
                              >
                                חריג
                              </Badge>
                            </TableCell>
                            <TableCell className="align-top font-mono text-sm">
                              {line.isPending ? (
                                <Input
                                  value={line.section_number}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      section_number: e.target.value,
                                    })
                                  }
                                  className="h-8 min-w-[4rem] font-mono text-sm"
                                  dir="ltr"
                                />
                              ) : (
                                line.section_number
                              )}
                            </TableCell>
                            <TableCell className="max-w-xs align-top">
                              {line.isPending ? (
                                <div className="space-y-2">
                                  <Input
                                    value={line.description}
                                    onChange={(e) =>
                                      updateLine(line.id, {
                                        description: e.target.value,
                                      })
                                    }
                                    dir="rtl"
                                    className="h-8"
                                  />
                                  <Input
                                    placeholder="תיאור הוראת שינוי"
                                    value={line.change_order_desc ?? ""}
                                    onChange={(e) =>
                                      updateLine(line.id, {
                                        change_order_desc:
                                          e.target.value || null,
                                      })
                                    }
                                    dir="rtl"
                                    className="h-8 text-xs"
                                  />
                                </div>
                              ) : (
                                <div>
                                  <span>{line.description}</span>
                                  {line.change_order_desc?.trim() ? (
                                    <p className="mt-1 text-xs text-muted-foreground">
                                      {line.change_order_desc}
                                    </p>
                                  ) : null}
                                </div>
                              )}
                            </TableCell>
                            <TableCell className="align-top">
                              {line.isPending ? (
                                <Input
                                  value={line.unit ?? ""}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      unit: e.target.value || null,
                                    })
                                  }
                                  className="h-8 w-16"
                                  dir="rtl"
                                />
                              ) : (
                                (line.unit ?? "—")
                              )}
                            </TableCell>
                            <TableCell className="align-top text-end">
                              {line.isPending ? (
                                <Input
                                  type="number"
                                  inputMode="decimal"
                                  value={line.quantity ?? ""}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      quantity:
                                        e.target.value === ""
                                          ? null
                                          : Number(e.target.value),
                                    })
                                  }
                                  className="h-8 w-24 text-end"
                                />
                              ) : (
                                <span className="tabular-nums">
                                  {line.quantity ?? "—"}
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="align-top text-end">
                              {line.isPending ? (
                                <Input
                                  type="number"
                                  inputMode="decimal"
                                  value={line.unit_price ?? ""}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      unit_price:
                                        e.target.value === ""
                                          ? null
                                          : Number(e.target.value),
                                    })
                                  }
                                  className="h-8 w-28 text-end"
                                />
                              ) : (
                                <span className="tabular-nums">
                                  {line.unit_price != null
                                    ? currencyFormatter.format(
                                        Number(line.unit_price)
                                      )
                                    : "—"}
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="align-top">
                              <Select
                                value={line.change_order_status ?? "pending"}
                                onValueChange={(v) => {
                                  const st = v as MoChangeOrderStatus
                                  if (line.isPending) {
                                    updateLine(line.id, {
                                      change_order_status: st,
                                    })
                                  } else {
                                    void updateChangeOrderLineStatus(
                                      line.id,
                                      st
                                    )
                                  }
                                }}
                              >
                                <SelectTrigger className="h-8 w-[8.5rem]">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="pending">
                                    ממתין לאישור
                                  </SelectItem>
                                  <SelectItem value="approved">מאושר</SelectItem>
                                  <SelectItem value="rejected">נדחה</SelectItem>
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell className="text-end font-medium tabular-nums">
                              {currencyFormatter.format(lineBaseAmount(line))}
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="gap-1.5 border-amber-500/40 text-amber-900 hover:bg-amber-500/10 dark:text-amber-200"
                  onClick={addChangeOrderRow}
                  disabled={savingPartialAccount}
                >
                  <Plus className="size-4" aria-hidden />
                  הוסף עבודה נוספת / חריג
                </Button>
              </TabsContent>

              <TabsContent value="tenant" className="mt-0 space-y-4">
                <div className="rounded-lg border border-violet-500/25 bg-violet-500/[0.04] p-4 text-sm text-muted-foreground">
                  <p className="font-medium text-foreground">
                    מחירון ייחוס &quot;דקל&quot;
                  </p>
                  <p className="mt-1 text-xs">
                    בחירת פריט מהרשימה ממלאת אוטומטית תיאור, יחידה ומחיר יחידה
                    בשורה חדשה (ניתן לערוך לפני שמירה).
                  </p>
                  <div className="mt-3 max-w-md">
                    <Label className="text-xs">הוספה מהירה ממחירון</Label>
                    <Select
                      onValueChange={(v) => {
                        const item = DEKEL_REFERENCE_PRICE_LIST.find(
                          (d) => d.code === v
                        )
                        if (item) addTenantChangeFromDekel(item)
                      }}
                    >
                      <SelectTrigger className="mt-1 w-full">
                        <SelectValue placeholder="בחרו פריט מהמחירון…" />
                      </SelectTrigger>
                      <SelectContent>
                        {DEKEL_REFERENCE_PRICE_LIST.map((d) => (
                          <SelectItem key={d.code} value={d.code}>
                            <span className="font-mono text-xs">{d.code}</span>{" "}
                            {d.description} —{" "}
                            {currencyFormatter.format(d.unit_price)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex flex-col gap-3 rounded-lg border border-violet-500/20 bg-violet-500/[0.06] p-4 sm:flex-row sm:flex-wrap sm:items-end">
                  <div className="min-w-[8rem] flex-1 space-y-1.5">
                    <Label htmlFor="tenant-filter-floor" className="text-xs">
                      סינון קומה
                    </Label>
                    <Input
                      id="tenant-filter-floor"
                      value={tenantFloorFilter}
                      onChange={(e) => setTenantFloorFilter(e.target.value)}
                      placeholder="למשל 3"
                      className="h-9"
                      dir="ltr"
                    />
                  </div>
                  <div className="min-w-[8rem] flex-1 space-y-1.5">
                    <Label htmlFor="tenant-filter-apt" className="text-xs">
                      סינון דירה
                    </Label>
                    <Input
                      id="tenant-filter-apt"
                      value={tenantAptFilter}
                      onChange={(e) => setTenantAptFilter(e.target.value)}
                      placeholder="למשל 12B"
                      className="h-9"
                      dir="ltr"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground sm:pb-2">
                    מוצגות {tenantLinesFiltered.length} שורות מתוך{" "}
                    {lines.filter((l) => l.line_kind === "tenant_change").length}
                  </p>
                </div>
                <div className="overflow-x-auto rounded-lg border border-violet-500/25 bg-violet-500/[0.03]">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-violet-500/15 hover:bg-violet-500/15">
                        <TableHead className="w-11 px-0 text-center">
                          <span className="sr-only">הערות</span>
                        </TableHead>
                        <TableHead className="w-10" />
                        <TableHead>קומה</TableHead>
                        <TableHead>דירה</TableHead>
                        <TableHead>תיאור השינוי</TableHead>
                        <TableHead>יחידה</TableHead>
                        <TableHead className="text-end">כמות</TableHead>
                        <TableHead className="text-end">מחיר יחידה</TableHead>
                        <TableHead className="text-end">סכום</TableHead>
                        <TableHead>סטטוס</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {tenantLinesFiltered.map((line) => (
                          <TableRow
                            key={line.id}
                            className="bg-violet-500/[0.04] dark:bg-violet-500/10"
                          >
                            <TableCell className="w-11 p-1 align-top">
                              <MoContextCommentButton
                                projectId={contract.project_id}
                                projectName={commentProjectName}
                                contextType="contract_item"
                                contextId={line.isPending ? null : line.id}
                                contextLabel={`דייר ${line.section_number}`}
                                hasComment={lineHasComment(line.id)}
                                disabled={line.isPending}
                              />
                            </TableCell>
                            <TableCell className="align-top">
                              <Badge
                                variant="outline"
                                className="border-violet-500/50 text-[10px] text-violet-800 dark:text-violet-300"
                              >
                                דייר
                              </Badge>
                            </TableCell>
                            <TableCell className="align-top">
                              {line.isPending ? (
                                <Input
                                  value={line.tenant_floor ?? ""}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      tenant_floor: e.target.value,
                                    })
                                  }
                                  placeholder="קומה"
                                  className="h-8 w-16 font-mono text-sm"
                                  dir="ltr"
                                />
                              ) : (
                                <Input
                                  value={line.tenant_floor ?? ""}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      tenant_floor: e.target.value || null,
                                    })
                                  }
                                  onBlur={(e) =>
                                    void persistTenantFloor(line.id, e.target.value)
                                  }
                                  className="h-8 w-16 font-mono text-sm"
                                  dir="ltr"
                                />
                              )}
                            </TableCell>
                            <TableCell className="align-top">
                              {line.isPending ? (
                                <Input
                                  value={line.apartment_number ?? ""}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      apartment_number: e.target.value,
                                    })
                                  }
                                  placeholder="למשל 12B"
                                  className="h-8 min-w-[5rem] font-mono text-sm"
                                  dir="ltr"
                                />
                              ) : (
                                <span className="font-mono">
                                  {line.apartment_number?.trim() || "—"}
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="max-w-xs align-top">
                              {line.isPending ? (
                                <Input
                                  value={line.description}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      description: e.target.value,
                                    })
                                  }
                                  placeholder="למשל הזזת נקודת מאור"
                                  dir="rtl"
                                  className="h-8"
                                />
                              ) : (
                                line.description
                              )}
                            </TableCell>
                            <TableCell className="align-top">
                              {line.isPending ? (
                                <Input
                                  value={line.unit ?? ""}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      unit: e.target.value || null,
                                    })
                                  }
                                  className="h-8 w-16"
                                  dir="rtl"
                                />
                              ) : (
                                (line.unit ?? "—")
                              )}
                            </TableCell>
                            <TableCell className="align-top text-end">
                              {line.isPending ? (
                                <Input
                                  type="number"
                                  inputMode="decimal"
                                  value={line.quantity ?? ""}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      quantity:
                                        e.target.value === ""
                                          ? null
                                          : Number(e.target.value),
                                    })
                                  }
                                  className="h-8 w-24 text-end"
                                />
                              ) : (
                                <span className="tabular-nums">
                                  {line.quantity ?? "—"}
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="align-top text-end">
                              {line.isPending ? (
                                <Input
                                  type="number"
                                  inputMode="decimal"
                                  value={line.unit_price ?? ""}
                                  onChange={(e) =>
                                    updateLine(line.id, {
                                      unit_price:
                                        e.target.value === ""
                                          ? null
                                          : Number(e.target.value),
                                    })
                                  }
                                  className="h-8 w-28 text-end"
                                />
                              ) : (
                                <span className="tabular-nums">
                                  {line.unit_price != null
                                    ? currencyFormatter.format(
                                        Number(line.unit_price)
                                      )
                                    : "—"}
                                </span>
                              )}
                            </TableCell>
                            <TableCell className="text-end font-medium tabular-nums">
                              {currencyFormatter.format(lineBaseAmount(line))}
                            </TableCell>
                            <TableCell className="align-top">
                              {line.isPending ? (
                                <Select
                                  value={line.tenant_change_status ?? "pending"}
                                  onValueChange={(v) =>
                                    updateLine(line.id, {
                                      tenant_change_status:
                                        v === "approved"
                                          ? "approved"
                                          : "pending",
                                    })
                                  }
                                >
                                  <SelectTrigger className="h-8 w-[8.5rem]">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="pending">
                                      ממתין לאישור
                                    </SelectItem>
                                    <SelectItem value="approved">מאושר</SelectItem>
                                  </SelectContent>
                                </Select>
                              ) : (
                                <Select
                                  value={line.tenant_change_status ?? "pending"}
                                  onValueChange={(v) =>
                                    void updateTenantLineStatus(
                                      line.id,
                                      v === "approved" ? "approved" : "pending"
                                    )
                                  }
                                >
                                  <SelectTrigger className="h-8 w-[8.5rem]">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="pending">
                                      ממתין לאישור
                                    </SelectItem>
                                    <SelectItem value="approved">מאושר</SelectItem>
                                  </SelectContent>
                                </Select>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </div>
                {lines.filter((l) => l.line_kind === "tenant_change").length >
                  0 &&
                tenantLinesFiltered.length === 0 ? (
                  <p className="text-center text-sm text-muted-foreground">
                    אין שורות התואמות לסינון. נקו את השדות או שנו את החיפוש.
                  </p>
                ) : null}
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="gap-1.5 border-violet-500/40 text-violet-900 hover:bg-violet-500/10 dark:text-violet-200"
                  onClick={addTenantChangeRow}
                  disabled={savingPartialAccount}
                >
                  <Home className="size-4" aria-hidden />
                  הוסף שינוי דייר
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card className="border-border/70 shadow-sm">
          <CardHeader className="border-b border-border/60">
            <div className="flex items-center gap-2">
              <Calculator className="size-5 text-muted-foreground" />
              <div>
                <CardTitle>חשבון חלקי — רשת חכמה</CardTitle>
                <CardDescription>
                  מוגש מול מאושר: העתקה אופטימית ממוגש למאושר, ניתן לעדכן מאושר
                  ידנית. עכבון וביטוח מחושבים לפי סה״כ מאושר בלבד.
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6 pt-4">
            {lines.length === 0 ? (
              <p className="py-4 text-center text-sm text-muted-foreground">
                אין סעיפים לחישוב חשבון חלקי.
              </p>
            ) : (
              <div className="overflow-x-auto rounded-lg border border-border/50">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/40 hover:bg-muted/40">
                      <TableHead className="w-11 px-0 text-center">
                        <span className="sr-only">הערות</span>
                      </TableHead>
                      <TableHead className="w-10" />
                      <TableHead>סעיף</TableHead>
                      <TableHead>תיאור</TableHead>
                      <TableHead className="text-end">סכום שורה</TableHead>
                      <TableHead className="min-w-[5.5rem]">מוגש %</TableHead>
                      <TableHead className="min-w-[5.5rem]">מאושר %</TableHead>
                      <TableHead className="text-center text-xs font-normal text-muted-foreground">
                        הפרש
                      </TableHead>
                      <TableHead className="text-end">סכום מוגש</TableHead>
                      <TableHead className="text-end">סכום מאושר</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {lines.map((line) => {
                      const sub = parsePct(submittedPct[line.id] ?? "")
                      const app = parsePct(approvedPct[line.id] ?? "")
                      const base = lineBaseAmount(line)
                      const subAmt = base * (sub / 100)
                      const appAmt = base * (app / 100)
                      const deltaMoney = roundMoney(subAmt - appAmt)
                      const deltaPct = roundMoney(sub - app)
                      const showDelta =
                        Math.abs(deltaMoney) > 0.005 || Math.abs(deltaPct) > 0.005
                      return (
                        <TableRow
                          key={`partial-${line.id}`}
                          className={cn(
                            line.line_kind === "extra_work" &&
                              "bg-amber-500/[0.06] dark:bg-amber-500/10",
                            line.line_kind === "tenant_change" &&
                              "bg-violet-500/[0.06] dark:bg-violet-500/10",
                            line.line_kind === "original" &&
                              "bg-sky-500/[0.04] dark:bg-sky-500/10"
                          )}
                        >
                          <TableCell className="w-11 p-1 align-top">
                            <MoContextCommentButton
                              projectId={contract.project_id}
                              projectName={commentProjectName}
                              contextType="contract_item"
                              contextId={line.isPending ? null : line.id}
                              contextLabel={`סעיף ${line.section_number}`}
                              hasComment={lineHasComment(line.id)}
                              disabled={line.isPending}
                            />
                          </TableCell>
                          <TableCell>
                            {line.line_kind === "extra_work" ? (
                              <div className="flex flex-col gap-1">
                                <Badge
                                  variant="outline"
                                  className="border-amber-500/40 text-[10px] text-amber-700 dark:text-amber-400"
                                >
                                  חריג
                                </Badge>
                                <span className="text-[9px] text-muted-foreground">
                                  {line.change_order_status === "approved"
                                    ? "מאושר"
                                    : line.change_order_status === "rejected"
                                      ? "נדחה"
                                      : "ממתין"}
                                </span>
                              </div>
                            ) : line.line_kind === "tenant_change" ? (
                              <Badge
                                variant="outline"
                                className="border-violet-500/40 text-[10px] text-violet-700 dark:text-violet-400"
                              >
                                דייר
                              </Badge>
                            ) : (
                              <Badge
                                variant="secondary"
                                className="text-[10px] text-sky-800 dark:text-sky-300"
                              >
                                חוזה
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell className="font-mono text-sm">
                            {line.section_number}
                          </TableCell>
                          <TableCell className="max-w-[180px] truncate">
                            {line.description}
                          </TableCell>
                          <TableCell className="text-end tabular-nums">
                            {currencyFormatter.format(base)}
                          </TableCell>
                          <TableCell>
                            <Label
                              htmlFor={`sub-${line.id}`}
                              className="sr-only"
                            >
                              מוגש % לסעיף {line.section_number}
                            </Label>
                            <Input
                              id={`sub-${line.id}`}
                              type="number"
                              inputMode="decimal"
                              min={0}
                              max={100}
                              step="0.01"
                              placeholder="0"
                              value={submittedPct[line.id] ?? ""}
                              onChange={(e) =>
                                handleSubmittedChange(line.id, e.target.value)
                              }
                              className="h-9 w-full max-w-[5.5rem]"
                            />
                          </TableCell>
                          <TableCell>
                            <Label
                              htmlFor={`app-${line.id}`}
                              className="sr-only"
                            >
                              מאושר % לסעיף {line.section_number}
                            </Label>
                            <Input
                              id={`app-${line.id}`}
                              type="number"
                              inputMode="decimal"
                              min={0}
                              max={100}
                              step="0.01"
                              placeholder="0"
                              value={approvedPct[line.id] ?? ""}
                              onChange={(e) =>
                                handleApprovedChange(line.id, e.target.value)
                              }
                              className="h-9 w-full max-w-[5.5rem]"
                            />
                          </TableCell>
                          <TableCell className="text-center">
                            {showDelta ? (
                              <Badge
                                variant="secondary"
                                className="font-normal tabular-nums text-[10px] text-muted-foreground"
                              >
                                {currencyFormatter.format(deltaMoney)} ·{" "}
                                {deltaPct > 0 ? "+" : ""}
                                {deltaPct.toFixed(2)}%
                              </Badge>
                            ) : (
                              <span className="text-xs text-muted-foreground">
                                —
                              </span>
                            )}
                          </TableCell>
                          <TableCell className="text-end tabular-nums text-sky-700 dark:text-sky-400">
                            {currencyFormatter.format(subAmt)}
                          </TableCell>
                          <TableCell className="text-end font-medium tabular-nums text-emerald-700 dark:text-emerald-400">
                            {currencyFormatter.format(appAmt)}
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            )}

            <div className="grid gap-4 rounded-xl border border-border/60 bg-muted/20 p-4 lg:grid-cols-2">
              <div className="space-y-3 border-border/50 lg:border-e lg:pe-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  מוגש (תביעה)
                </p>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">סה״כ מוגש</p>
                  <p className="text-lg font-bold tabular-nums text-sky-700 dark:text-sky-400">
                    {currencyFormatter.format(totals.totalSubmitted)}
                  </p>
                </div>
              </div>
              <div className="space-y-3 lg:ps-1">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  מאושר (תעודה) — בסיס לניכויים
                </p>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">סה״כ מאושר</p>
                  <p className="text-lg font-bold tabular-nums text-emerald-700 dark:text-emerald-400">
                    {currencyFormatter.format(totals.totalApproved)}
                  </p>
                </div>
                <div className="pt-2 print:hidden">
                  <Button
                    type="button"
                    size="sm"
                    variant="secondary"
                    className="gap-2 border border-emerald-500/40 bg-emerald-500/10 text-emerald-900 hover:bg-emerald-500/20 dark:text-emerald-100"
                    onClick={() => setIssueInvoiceOpen(true)}
                    disabled={!contract}
                  >
                    <FileText className="size-4" aria-hidden />
                    הפק חשבונית מס ללקוח
                  </Button>
                </div>
                <div className="grid gap-3 border-t border-border/50 pt-3 sm:grid-cols-2">
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-muted-foreground">
                      פחת עכבון ({totals.retentionPct}%)
                    </p>
                    <p className="text-base font-bold tabular-nums text-amber-700 dark:text-amber-400">
                      −{currencyFormatter.format(totals.retentionAmount)}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-muted-foreground">
                      פחת ביטוח ({totals.insurancePct}%)
                    </p>
                    <p className="text-base font-bold tabular-nums text-amber-700 dark:text-amber-400">
                      −{currencyFormatter.format(totals.insuranceAmount)}
                    </p>
                  </div>
                </div>
                <div className="border-t border-border/50 pt-3">
                  <p className="text-xs font-medium text-muted-foreground">
                    לתשלום (לפני מע״מ)
                  </p>
                  <p className="text-xl font-bold tabular-nums text-emerald-600 dark:text-emerald-400">
                    {currencyFormatter.format(totals.finalPayout)}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap justify-end gap-2 print:hidden">
              <Button
                type="button"
                size="lg"
                variant="outline"
                className="gap-2"
                onClick={handlePrintPdf}
                disabled={lines.length === 0}
              >
                <Printer className="size-4" aria-hidden />
                הדפס חשבון / PDF
              </Button>
              <Button
                type="button"
                size="lg"
                className="gap-2 bg-cyan-600 text-white hover:bg-cyan-500"
                onClick={() => void handleGeneratePartialAccount()}
                disabled={lines.length === 0 || savingPartialAccount}
              >
                {savingPartialAccount ? (
                  <Loader2 className="size-4 animate-spin" aria-hidden />
                ) : (
                  <Receipt className="size-4" aria-hidden />
                )}
                {savingPartialAccount ? "שומרים…" : "הפק חשבון חלקי"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      </DualPaneLayout>

      <div
        dir="rtl"
        lang="he"
        className="hidden print:absolute print:inset-0 print:z-[100] print:block print:min-h-screen print:w-full print:bg-white print:p-8 print:text-black"
      >
        <header className="mb-6 border-b-2 border-black pb-4 print:border-black">
          <div className="grid grid-cols-2 gap-6 text-xs leading-relaxed print:text-black">
            <div className="space-y-1 text-end">
              <h2 className="text-base font-bold tracking-tight print:text-black">
                {issuer?.company_name ?? "—"}
              </h2>
              {issuer?.address ? (
                <p className="whitespace-pre-line print:text-black">
                  {issuer.address}
                </p>
              ) : (
                <p className="text-neutral-600 print:text-black">כתובת: —</p>
              )}
              <p className="print:text-black">
                {issuer?.phone ? (
                  <>
                    טל&apos;:{" "}
                    <span className="tabular-nums">{issuer.phone}</span>
                  </>
                ) : (
                  "טל׳: —"
                )}
                {issuer?.email ? (
                  <>
                    {" · "}
                    דוא&quot;ל: {issuer.email}
                  </>
                ) : null}
              </p>
              <p className="font-semibold print:text-black">
                עוסק מורשה / ח.פ:{" "}
                <span className="font-normal tabular-nums">
                  {issuer?.legal_id?.trim() || "—"}
                </span>
              </p>
              <p className="print:text-black">
                מס&apos; תיק ניכויים:{" "}
                <span className="tabular-nums font-medium">
                  {issuer?.deductions_file_number?.trim() || "—"}
                </span>
              </p>
            </div>
            <div className="space-y-2 text-start">
              <h1 className="text-lg font-bold print:text-black">
                חשבון חלקי מס&apos;{" "}
                {lastPartialAccountNumber != null
                  ? String(lastPartialAccountNumber)
                  : "______"}
              </h1>
              <p className="text-[11px] text-neutral-700 print:text-black">
                {lastPartialAccountNumber != null
                  ? "מספר אושר ונשמר במערכת."
                  : "תצוגה מוקדמת — יונפק מספר רשמי לאחר שמירת החשבון החלקי."}
              </p>
              <p className="font-semibold print:text-black">
                תאריך הנפקה:{" "}
                <span className="font-normal">{issueDateLabel}</span>
              </p>
            </div>
          </div>
        </header>

        <section className="mb-6 border border-black p-4 text-sm print:border-black print:text-black">
          <p className="mb-2 font-bold">לכבוד (לקוח / ישות חוזית):</p>
          <p className="text-base font-semibold">{entityName}</p>
          <p className="mt-1 whitespace-pre-line">{clientAddress}</p>
          <p className="mt-2">
            <span className="font-semibold">ח.פ / ע.מ:</span>{" "}
            <span className="tabular-nums">{clientLegalId}</span>
          </p>
          {contract.entities?.deductions_file_number?.trim() ? (
            <p className="mt-1">
              <span className="font-semibold">תיק ניכויים (לקוח):</span>{" "}
              <span className="tabular-nums">
                {contract.entities.deductions_file_number.trim()}
              </span>
            </p>
          ) : null}
        </section>

        <section className="mb-6 grid gap-2 text-sm print:text-black">
          <div className="grid grid-cols-[8rem_1fr] gap-x-3 gap-y-1 border border-black p-3 print:border-black">
            <span className="font-semibold">שם פרויקט:</span>
            <span>{projectName}</span>
            <span className="font-semibold">כתובת אתר:</span>
            <span className="whitespace-pre-line">{projectAddress}</span>
            <span className="font-semibold">סוג הסכם:</span>
            <span>{agreementLabel}</span>
            <span className="font-semibold">קוד פרויקט:</span>
            <span className="font-mono">
              {contract.projects?.internal_project_code ?? "—"}
            </span>
          </div>
        </section>

        {(
          [
            {
              key: "boq",
              title: "א׳ — סעיפי חוזה (כתב כמויות מקורי)",
              subset: lines.filter((l) => l.line_kind === "original"),
            },
            {
              key: "extra",
              title: "ב׳ — עבודות נוספות / חריגים",
              subset: lines.filter((l) => l.line_kind === "extra_work"),
            },
            {
              key: "tenant",
              title: "ג׳ — שינויי דיירים",
              subset: lines.filter((l) => l.line_kind === "tenant_change"),
            },
          ] as const
        ).map(({ key, title, subset }) =>
          subset.length === 0 ? null : (
            <section key={key} className="mb-6 print:break-inside-avoid">
              <h3 className="mb-2 border-b-2 border-black pb-1 text-sm font-bold print:border-black">
                {title}
              </h3>
              <table className="w-full border-collapse border border-black text-[10px] print:border-black">
                <thead>
                  <tr className="bg-neutral-100 print:bg-neutral-100">
                    <th className="border border-black px-1 py-1 font-semibold print:border-black">
                      סעיף / דירה
                    </th>
                    <th className="border border-black px-1 py-1 font-semibold print:border-black">
                      תיאור
                    </th>
                    <th className="border border-black px-1 py-1 font-semibold print:border-black">
                      כמות
                    </th>
                    <th className="border border-black px-1 py-1 font-semibold print:border-black">
                      מחיר יח׳
                    </th>
                    <th className="border border-black px-1 py-1 font-semibold print:border-black">
                      % מוגש
                    </th>
                    <th className="border border-black px-1 py-1 font-semibold print:border-black">
                      סכום מוגש
                    </th>
                    <th className="border border-black px-1 py-1 font-semibold print:border-black">
                      % מאושר
                    </th>
                    <th className="border border-black px-1 py-1 font-semibold print:border-black">
                      סכום מאושר
                    </th>
                    <th className="border border-black px-1 py-1 font-semibold print:border-black">
                      הפרש
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {subset.map((line) => {
                    const sub = parsePct(submittedPct[line.id] ?? "")
                    const app = parsePct(approvedPct[line.id] ?? "")
                    const q = Number(line.quantity) || 0
                    const unitP = Number(line.unit_price) || 0
                    const base = lineBaseAmount(line)
                    const subAmt = base * (sub / 100)
                    const appAmt = base * (app / 100)
                    const delta = roundMoney(subAmt - appAmt)
                    const sectionCell =
                      line.line_kind === "tenant_change"
                        ? line.apartment_number?.trim() || line.section_number
                        : line.section_number
                    return (
                      <tr key={`print-${key}-${line.id}`}>
                        <td className="border border-black px-1 py-0.5 font-mono print:border-black">
                          {sectionCell}
                        </td>
                        <td className="border border-black px-1 py-0.5 print:border-black">
                          {buildPrintLineDescription(line)}
                        </td>
                        <td className="border border-black px-1 py-0.5 text-end tabular-nums print:border-black">
                          {qtyPrintFormatter.format(q)}
                        </td>
                        <td className="border border-black px-1 py-0.5 text-end tabular-nums print:border-black">
                          {currencyFormatter.format(unitP)}
                        </td>
                        <td className="border border-black px-1 py-0.5 text-end tabular-nums print:border-black">
                          {sub.toFixed(2)}%
                        </td>
                        <td className="border border-black px-1 py-0.5 text-end tabular-nums print:border-black">
                          {currencyFormatter.format(subAmt)}
                        </td>
                        <td className="border border-black px-1 py-0.5 text-end tabular-nums print:border-black">
                          {app.toFixed(2)}%
                        </td>
                        <td className="border border-black px-1 py-0.5 text-end font-medium tabular-nums print:border-black">
                          {currencyFormatter.format(appAmt)}
                        </td>
                        <td className="border border-black px-1 py-0.5 text-end tabular-nums print:border-black">
                          {currencyFormatter.format(delta)}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </section>
          )
        )}

        {lines.length === 0 ? (
          <section className="mb-6 text-sm print:text-black">
            <p>אין שורות להצגה בכתב הכמויות.</p>
          </section>
        ) : null}

        <footer className="mt-4">
          <h3 className="mb-2 border-b border-black pb-1 text-sm font-bold print:border-black">
            סיכום מסמך
          </h3>
          <table className="ms-auto w-full max-w-lg border-collapse border border-black text-[10px] print:border-black">
            <tbody>
              <tr className="bg-neutral-200 print:bg-neutral-200">
                <td
                  colSpan={2}
                  className="border border-black px-2 py-1 text-center font-bold print:border-black"
                >
                  מצב חשבונאי — סיכום פרויקט
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  סה״כ חוזה מקורי
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  {currencyFormatter.format(accountingSummary.originalBase)}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  סה״כ חריגים מאושרים (לפי % מאושר)
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  {currencyFormatter.format(
                    accountingSummary.extraApprovedPartial
                  )}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  סה״כ שינויי דיירים (מאושר)
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  {currencyFormatter.format(accountingSummary.tenantApproved)}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  שינויי דיירים בהמתנה
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  {currencyFormatter.format(accountingSummary.tenantPending)}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-semibold print:border-black">
                  סה״כ מצטבר לביצוע
                </td>
                <td className="border border-black px-2 py-1 text-end font-semibold tabular-nums print:border-black">
                  {currencyFormatter.format(
                    accountingSummary.cumulativeExecution
                  )}
                </td>
              </tr>
              <tr className="bg-neutral-100 print:bg-neutral-100">
                <td
                  colSpan={2}
                  className="border border-black px-2 py-1 text-center text-[9px] font-semibold print:border-black"
                >
                  חשבון חלקי — מוגש / מאושר וניכויים
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  סכום חוזה כולל (במערכת)
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  {currencyFormatter.format(contractTotalNum)}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  אחוז מוגש (משוקלל)
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  {printTotals.submittedWeightedPct.toFixed(2)}%
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  אחוז מאושר (משוקלל)
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  {printTotals.approvedWeightedPct.toFixed(2)}%
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  סה״כ מוגש (ביניים)
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  {currencyFormatter.format(totals.totalSubmitted)}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  סה״כ מאושר (ביניים)
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  {currencyFormatter.format(totals.totalApproved)}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  עכבון על מאושר (−{totals.retentionPct}%)
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  −{currencyFormatter.format(totals.retentionAmount)}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  ביטוח על מאושר (−{totals.insurancePct}%)
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  −{currencyFormatter.format(totals.insuranceAmount)}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-semibold print:border-black">
                  לתשלום לפני מע״מ (לפי מאושר)
                </td>
                <td className="border border-black px-2 py-1 text-end font-semibold tabular-nums print:border-black">
                  {currencyFormatter.format(printTotals.paymentBeforeVat)}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  מע״מ ({VAT_RATE * 100}%)
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  {currencyFormatter.format(printTotals.vatAmount)}
                </td>
              </tr>
              <tr className="bg-neutral-100 print:bg-neutral-100">
                <td className="border border-black px-2 py-1.5 font-bold print:border-black">
                  סה״כ כולל מע״מ
                </td>
                <td className="border border-black px-2 py-1.5 text-end text-sm font-bold tabular-nums print:border-black">
                  {currencyFormatter.format(printTotals.grandTotal)}
                </td>
              </tr>
            </tbody>
          </table>

          <h3 className="mb-2 mt-8 border-b border-black pb-1 text-sm font-bold print:mt-6 print:border-black">
            טבלת ריכוז — תשלומים והיקף
          </h3>
          <table className="ms-auto mb-6 w-full max-w-lg border-collapse border border-black text-[10px] print:border-black">
            <tbody>
              <tr className="bg-neutral-100 print:bg-neutral-100">
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  סה״כ פרויקט (חוזה + שינויים מאושרים)
                </td>
                <td className="border border-black px-2 py-1 text-end font-semibold tabular-nums print:border-black">
                  {currencyFormatter.format(
                    grandFinancialSummary.totalProjectScope
                  )}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  סה״כ מאושר למועד (כולל מצב נוכחי)
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  {currencyFormatter.format(
                    grandFinancialSummary.totalApprovedToDate
                  )}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-medium print:border-black">
                  תשלומים קודמים (חוזה)
                </td>
                <td className="border border-black px-2 py-1 text-end tabular-nums print:border-black">
                  {currencyFormatter.format(grandFinancialSummary.priorPayments)}
                </td>
              </tr>
              <tr>
                <td className="border border-black px-2 py-1 font-semibold print:border-black">
                  לתשלום נוכחי (נטו לפני מע״מ)
                </td>
                <td className="border border-black px-2 py-1 text-end font-semibold tabular-nums print:border-black">
                  {currencyFormatter.format(
                    grandFinancialSummary.currentPaymentDueNet
                  )}
                </td>
              </tr>
            </tbody>
          </table>

          <p className="mt-4 text-[10px] text-neutral-600">
            מוגש = תביעת הקבלן · מאושר = אישור מזמין / יועץ · ניכויים לפי מאושר בלבד.
          </p>
        </footer>
      </div>

      {contract ? (
        <IssueClientInvoiceDialog
          open={issueInvoiceOpen}
          onOpenChange={setIssueInvoiceOpen}
          contractId={contract.id}
          projectId={contract.project_id}
          defaultSubtotal={totals.finalPayout}
          onIssued={(invId) => {
            window.open(
              `/marker-ofek/finance/invoices/${invId}/print`,
              "_blank",
              "noopener,noreferrer"
            )
          }}
        />
      ) : null}
    </>
  )
}
