"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import * as React from "react"
import {
  ArrowRight,
  BookOpen,
  Calculator,
  FileSignature,
  ListPlus,
  Loader2,
  Plus,
  Save,
  Tags,
  Trash2,
} from "lucide-react"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { DualPaneLayout } from "@/components/marker-ofek/workspace/dual-pane-layout"
import { createSupabaseBrowserClient } from "@/lib/supabase/browser"
import { cn } from "@/lib/utils"

type ContractTypeValue = "main_contract" | "sub_contract"

type BoqRow = {
  id: string
  sectionCode: string
  description: string
  unit: string
  quantity: string
  unitPrice: string
}

function createEmptyBoqRow(): BoqRow {
  return {
    id: crypto.randomUUID(),
    sectionCode: "",
    description: "",
    unit: "",
    quantity: "",
    unitPrice: "",
  }
}

function parseNum(s: string): number {
  const n = parseFloat(String(s).replace(",", "."))
  return Number.isFinite(n) ? n : 0
}

function computeBoqTotal(rows: BoqRow[]): number {
  return rows.reduce((sum, row) => {
    return sum + parseNum(row.quantity) * parseNum(row.unitPrice)
  }, 0)
}

/** שורות BoQ תקפות להכנסה ל-DB (סעיף + תיאור חובה בטבלה) */
function getValidBoqRowsForDb(rows: BoqRow[]) {
  return rows.filter(
    (r) => r.sectionCode.trim().length > 0 && r.description.trim().length > 0
  )
}

const currencyFormatter = new Intl.NumberFormat("he-IL", {
  style: "currency",
  currency: "ILS",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})

export default function NewMarkerOfekContractPage() {
  const router = useRouter()
  const [projectName, setProjectName] = React.useState("")
  const [entityName, setEntityName] = React.useState("")
  const [contractType, setContractType] = React.useState<ContractTypeValue>(
    "main_contract"
  )
  const [agreementType, setAgreementType] = React.useState("פאושלי")
  const [retentionPct, setRetentionPct] = React.useState("5")
  const [insurancePct, setInsurancePct] = React.useState("0.6")
  const [rows, setRows] = React.useState<BoqRow[]>(() => [createEmptyBoqRow()])
  const [isSubmitting, setIsSubmitting] = React.useState(false)
  const [entityLegalId, setEntityLegalId] = React.useState("")
  const [entityAddress, setEntityAddress] = React.useState("")
  const [entityDeductionsFile, setEntityDeductionsFile] = React.useState("")
  const [dualSplit, setDualSplit] = React.useState(false)

  const boqTotal = React.useMemo(() => computeBoqTotal(rows), [rows])

  function updateRow(id: string, patch: Partial<BoqRow>) {
    setRows((prev) =>
      prev.map((r) => (r.id === id ? { ...r, ...patch } : r))
    )
  }

  function addRow() {
    setRows((prev) => [...prev, createEmptyBoqRow()])
  }

  function removeRow(id: string) {
    setRows((prev) => {
      if (prev.length <= 1) return prev
      return prev.filter((r) => r.id !== id)
    })
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const pName = projectName.trim()
    const eName = entityName.trim()
    if (!pName || !eName) {
      toast.error("יש למלא שם פרויקט ושם ישות לפני השמירה")
      return
    }

    setIsSubmitting(true)
    const supabase = createSupabaseBrowserClient()

    try {
      const { data: existingEntity, error: entitySelectError } = await supabase
        .from("entities")
        .select("id")
        .eq("name", eName)
        .eq("is_deleted", false)
        .maybeSingle()

      if (entitySelectError) throw entitySelectError

      let entityId: string
      if (existingEntity?.id) {
        entityId = existingEntity.id
      } else {
        const { data: newEntity, error: entityInsertError } = await supabase
          .from("entities")
          .insert({
            name: eName,
            type: "subcontractor",
            contact_info: {},
            legal_id: entityLegalId.trim() || null,
            address: entityAddress.trim() || null,
            deductions_file_number: entityDeductionsFile.trim() || null,
          })
          .select("id")
          .single()

        if (entityInsertError) throw entityInsertError
        if (!newEntity?.id) throw new Error("לא התקבל מזהה ישות לאחר יצירה")
        entityId = newEntity.id
      }

      const { data: existingProject, error: projectSelectError } = await supabase
        .from("projects")
        .select("id")
        .eq("name", pName)
        .eq("is_deleted", false)
        .maybeSingle()

      if (projectSelectError) throw projectSelectError

      let projectId: string
      if (existingProject?.id) {
        projectId = existingProject.id
      } else {
        const { data: newProject, error: projectInsertError } = await supabase
          .from("projects")
          .insert({
            name: pName,
            internal_project_code: "",
            status: "planning",
          })
          .select("id")
          .single()

        if (projectInsertError) throw projectInsertError
        if (!newProject?.id) throw new Error("לא התקבל מזהה פרויקט לאחר יצירה")
        projectId = newProject.id
      }

      const retention = parseNum(retentionPct)
      const insurance = parseNum(insurancePct)

      const { data: newContract, error: contractInsertError } = await supabase
        .from("contracts")
        .insert({
          project_id: projectId,
          entity_id: entityId,
          contract_type: contractType,
          agreement_type: agreementType.trim() || null,
          retention_pct: retention,
          insurance_pct: insurance,
          total_amount: boqTotal,
          status: "draft",
        })
        .select("id")
        .single()

      if (contractInsertError) throw contractInsertError
      if (!newContract?.id) throw new Error("לא התקבל מזהה חוזה לאחר שמירה")
      const contractId = newContract.id

      const boqForDb = getValidBoqRowsForDb(rows)
      if (boqForDb.length > 0) {
        const linePayload = boqForDb.map((r) => ({
          contract_id: contractId,
          section_number: r.sectionCode.trim(),
          description: r.description.trim(),
          unit: r.unit.trim() || null,
          quantity: parseNum(r.quantity) || null,
          unit_price: parseNum(r.unitPrice) || null,
          is_change_order: false,
          line_kind: "original",
        }))

        const { error: linesError } = await supabase
          .from("contract_line_items")
          .insert(linePayload)

        if (linesError) {
          await supabase.from("contracts").delete().eq("id", contractId)
          throw linesError
        }
      }

      toast.success("החוזה נשמר בהצלחה")
      router.push("/marker-ofek/contracts")
      router.refresh()
    } catch (err) {
      const message =
        err instanceof Error ? err.message : typeof err === "object" && err !== null && "message" in err
          ? String((err as { message: unknown }).message)
          : String(err)
      console.error("[Marker Ofek] שמירת חוזה נכשלה", err)
      toast.error(`שמירת החוזה נכשלה: ${message}`)
    } finally {
      setIsSubmitting(false)
    }
  }

  const referencePanel = (
    <div className="space-y-4 text-sm leading-relaxed">
      <div className="rounded-lg border border-cyan-500/20 bg-cyan-500/5 p-3">
        <p className="flex items-center gap-2 font-semibold text-cyan-900 dark:text-cyan-200">
          <BookOpen className="size-4 shrink-0" aria-hidden />
          כתב כמויות (BoQ)
        </p>
        <ul className="mt-2 list-inside list-disc space-y-1 text-xs text-muted-foreground">
          <li>סעיף ותיאור חובה לכל שורה שנשמרת בבסיס הנתונים.</li>
          <li>כמות ומחיר יחידה לחישוב סה״כ אוטומטי.</li>
          <li>ניתן להוסיף שורות לפני השמירה.</li>
        </ul>
      </div>
      <Button
        variant="outline"
        size="sm"
        className="w-full justify-center gap-2 border-violet-500/30"
        render={<Link href="/marker-ofek/items" target="_blank" rel="noopener noreferrer" />}
      >
        <Tags className="size-4" aria-hidden />
        פתיחת קטלוג פריטים (לשונית חדשה)
      </Button>
      <p className="text-xs text-muted-foreground">
        מצב חצוי שומר על הטופס פעיל בזמן עיון בעזרים — ללא רענון הדף.
      </p>
    </div>
  )

  return (
    <DualPaneLayout
      split={dualSplit}
      onSplitChange={setDualSplit}
      referenceTitle="עזרים וקטלוג"
      reference={referencePanel}
    >
    <div className="mx-auto flex min-h-0 w-full max-w-4xl flex-1 flex-col gap-6 pb-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link
          href="/marker-ofek/contracts"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowRight className="size-4 rotate-180" aria-hidden />
          חזרה לרשימת חוזים
        </Link>
      </div>

      <div className="space-y-1">
        <h1 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
          יצירת חוזה חדש
        </h1>
        <p className="text-sm text-muted-foreground">
          מרקר אופק — הזנת פרטי חוזה, תנאים מסחריים וכתב כמויות (BoQ).
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="flex flex-col gap-6"
        aria-busy={isSubmitting}
      >
        <Card className="border-border/70 shadow-sm">
          <CardHeader className="border-b border-border/60 pb-4">
            <div className="flex items-start gap-3">
              <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-cyan-500/15 text-cyan-600 dark:text-cyan-400">
                <FileSignature className="size-5" aria-hidden />
              </div>
              <div className="space-y-1">
                <CardTitle>פרטי חוזה</CardTitle>
                <CardDescription>
                  פרויקט, ישות חוזית (מזמין / קבלן משנה) וסוג החוזה.
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="grid gap-5 pt-6 sm:grid-cols-2">
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="project-name">שם פרויקט</Label>
              <Input
                id="project-name"
                name="projectName"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                placeholder='לדוגמה: הירדן 89 רמת גן'
                dir="rtl"
                disabled={isSubmitting}
                className="w-full"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="entity-name">שם ישות (מזמין / קבלן משנה)</Label>
              <Input
                id="entity-name"
                name="entityName"
                value={entityName}
                onChange={(e) => setEntityName(e.target.value)}
                placeholder='לדוגמה: חיים מיכאלוביץ ניהול ביצוע ויזמות בע"מ'
                dir="rtl"
                disabled={isSubmitting}
                className="w-full"
              />
              <p className="text-xs text-muted-foreground">
                השדות הבאים נשמרים בבסיס הנתונים רק כשיוצרים ישות חדשה (שם שלא
                קיים במערכת).
              </p>
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="entity-legal-id">ח.פ / ע.מ (לישות חדשה)</Label>
              <Input
                id="entity-legal-id"
                name="entityLegalId"
                value={entityLegalId}
                onChange={(e) => setEntityLegalId(e.target.value)}
                placeholder="מספר רישום מס"
                dir="ltr"
                disabled={isSubmitting}
                className="w-full font-mono"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="entity-address">כתובת (לישות חדשה)</Label>
              <Input
                id="entity-address"
                name="entityAddress"
                value={entityAddress}
                onChange={(e) => setEntityAddress(e.target.value)}
                placeholder="רחוב, עיר, מיקוד"
                dir="rtl"
                disabled={isSubmitting}
                className="w-full"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="entity-deductions">
                תיק ניכויים (לישות חדשה)
              </Label>
              <Input
                id="entity-deductions"
                name="entityDeductionsFile"
                value={entityDeductionsFile}
                onChange={(e) => setEntityDeductionsFile(e.target.value)}
                placeholder="מספר תיק ניכויים אצל הלקוח"
                dir="ltr"
                disabled={isSubmitting}
                className="w-full font-mono"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="contract-type">סוג חוזה</Label>
              <Select
                value={contractType}
                disabled={isSubmitting}
                onValueChange={(v) =>
                  setContractType((v as ContractTypeValue) ?? "main_contract")
                }
              >
                <SelectTrigger id="contract-type" className="w-full min-w-0">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="main_contract">חוזה מזמין</SelectItem>
                  <SelectItem value="sub_contract">חוזה קבלן משנה</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/70 shadow-sm">
          <CardHeader className="border-b border-border/60 pb-4">
            <div className="flex items-start gap-3">
              <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-amber-500/15 text-amber-700 dark:text-amber-400">
                <Calculator className="size-5" aria-hidden />
              </div>
              <div className="space-y-1">
                <CardTitle>תנאים מסחריים</CardTitle>
                <CardDescription>
                  סוג הסכם, עכבון וביטוח — לפי תנאי החוזה.
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="grid gap-5 pt-6 sm:grid-cols-3">
            <div className="space-y-2 sm:col-span-3">
              <Label htmlFor="agreement-type">סוג הסכם</Label>
              <Input
                id="agreement-type"
                name="agreementType"
                value={agreementType}
                onChange={(e) => setAgreementType(e.target.value)}
                placeholder="פאושלי"
                dir="rtl"
                disabled={isSubmitting}
                className="w-full"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="retention-pct">אחוז עכבון (%)</Label>
              <Input
                id="retention-pct"
                name="retentionPct"
                type="number"
                inputMode="decimal"
                step="0.01"
                min={0}
                max={100}
                value={retentionPct}
                onChange={(e) => setRetentionPct(e.target.value)}
                disabled={isSubmitting}
                className="w-full"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="insurance-pct">אחוז ביטוח (%)</Label>
              <Input
                id="insurance-pct"
                name="insurancePct"
                type="number"
                inputMode="decimal"
                step="0.01"
                min={0}
                value={insurancePct}
                onChange={(e) => setInsurancePct(e.target.value)}
                disabled={isSubmitting}
                className="w-full"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/70 shadow-sm">
          <CardHeader className="flex flex-col gap-4 border-b border-border/60 pb-4 sm:flex-row sm:items-start sm:justify-between">
            <div className="flex items-start gap-3">
              <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-violet-500/15 text-violet-700 dark:text-violet-400">
                <ListPlus className="size-5" aria-hidden />
              </div>
              <div className="space-y-1">
                <CardTitle>כתב כמויות (BoQ)</CardTitle>
                <CardDescription>
                  הוסיפו סעיפים, כמויות ומחירי יחידה — הסכום הכולל מחושב אוטומטית.
                </CardDescription>
              </div>
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="shrink-0 gap-1.5 self-start"
              disabled={isSubmitting}
              onClick={addRow}
            >
              <Plus className="size-4" aria-hidden />
              הוסף סעיף
            </Button>
          </CardHeader>
          <CardContent className="space-y-4 pt-6">
            <div className="hidden rounded-lg border border-border/60 bg-muted/30 px-3 py-2 text-xs font-medium text-muted-foreground md:grid md:grid-cols-[minmax(0,1fr)_minmax(0,2fr)_minmax(0,0.7fr)_minmax(0,0.7fr)_minmax(0,0.9fr)_auto] md:gap-3">
              <span>סעיף</span>
              <span>תיאור</span>
              <span>יחידת מידה</span>
              <span>כמות</span>
              <span>מחיר יחידה</span>
              <span className="text-center">פעולות</span>
            </div>

            <ul className="flex flex-col gap-4">
              {rows.map((row, index) => (
                <li
                  key={row.id}
                  className="rounded-xl border border-border/60 bg-card/50 p-4 shadow-xs md:border-0 md:bg-transparent md:p-0 md:shadow-none"
                >
                  <div className="mb-2 text-xs font-medium text-muted-foreground md:hidden">
                    סעיף {index + 1}
                  </div>
                  <div className="grid gap-3 md:grid-cols-[minmax(0,1fr)_minmax(0,2fr)_minmax(0,0.7fr)_minmax(0,0.7fr)_minmax(0,0.9fr)_auto] md:items-end">
                    <div className="space-y-1.5">
                      <Label className="md:sr-only" htmlFor={`sec-${row.id}`}>
                        סעיף
                      </Label>
                      <Input
                        id={`sec-${row.id}`}
                        value={row.sectionCode}
                        onChange={(e) =>
                          updateRow(row.id, { sectionCode: e.target.value })
                        }
                        placeholder="01.08.01.0010"
                        dir="ltr"
                        disabled={isSubmitting}
                        className="w-full font-mono text-sm"
                      />
                    </div>
                    <div className="space-y-1.5 md:col-span-1">
                      <Label className="md:sr-only" htmlFor={`desc-${row.id}`}>
                        תיאור
                      </Label>
                      <Input
                        id={`desc-${row.id}`}
                        value={row.description}
                        onChange={(e) =>
                          updateRow(row.id, { description: e.target.value })
                        }
                        placeholder="הארקות יסוד"
                        dir="rtl"
                        disabled={isSubmitting}
                        className="w-full"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="md:sr-only" htmlFor={`unit-${row.id}`}>
                        יחידת מידה
                      </Label>
                      <Input
                        id={`unit-${row.id}`}
                        value={row.unit}
                        onChange={(e) =>
                          updateRow(row.id, { unit: e.target.value })
                        }
                        placeholder="קומ"
                        dir="rtl"
                        disabled={isSubmitting}
                        className="w-full"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="md:sr-only" htmlFor={`qty-${row.id}`}>
                        כמות
                      </Label>
                      <Input
                        id={`qty-${row.id}`}
                        type="number"
                        inputMode="decimal"
                        step="any"
                        value={row.quantity}
                        onChange={(e) =>
                          updateRow(row.id, { quantity: e.target.value })
                        }
                        placeholder="0"
                        disabled={isSubmitting}
                        className="w-full"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="md:sr-only" htmlFor={`price-${row.id}`}>
                        מחיר יחידה
                      </Label>
                      <Input
                        id={`price-${row.id}`}
                        type="number"
                        inputMode="decimal"
                        step="any"
                        value={row.unitPrice}
                        onChange={(e) =>
                          updateRow(row.id, { unitPrice: e.target.value })
                        }
                        placeholder="0"
                        disabled={isSubmitting}
                        className="w-full"
                      />
                    </div>
                    <div className="flex justify-end pb-0.5">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon-sm"
                        className={cn(
                          "text-destructive hover:bg-destructive/10 hover:text-destructive",
                          rows.length <= 1 && "pointer-events-none opacity-30"
                        )}
                        disabled={isSubmitting || rows.length <= 1}
                        onClick={() => removeRow(row.id)}
                        aria-label="מחק סעיף"
                      >
                        <Trash2 className="size-4" aria-hidden />
                      </Button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>

            <div className="flex flex-col items-stretch justify-between gap-2 rounded-xl border border-cyan-500/30 bg-cyan-500/5 px-4 py-3 sm:flex-row sm:items-center">
              <span className="text-sm font-medium text-foreground">
                סכום כולל (מחושב מכתב הכמויות)
              </span>
              <span className="text-lg font-bold tabular-nums text-cyan-700 dark:text-cyan-400">
                {currencyFormatter.format(boqTotal)}
              </span>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-3 border-t border-border/60 pt-6 sm:flex-row sm:justify-end">
            <Button
              type="submit"
              size="lg"
              disabled={isSubmitting}
              className="w-full gap-2 bg-cyan-600 text-white hover:bg-cyan-500 sm:w-auto"
            >
              {isSubmitting ? (
                <Loader2 className="size-4 animate-spin" aria-hidden />
              ) : (
                <Save className="size-4" aria-hidden />
              )}
              {isSubmitting ? "שומרים…" : "שמירת חוזה"}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
    </DualPaneLayout>
  )
}
