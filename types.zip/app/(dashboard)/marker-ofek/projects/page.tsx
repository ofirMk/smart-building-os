import Link from "next/link"
import { ArrowRight, CalendarDays } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

export default function MarkerOfekProjectsPage() {
  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col gap-6 pb-10">
      <Link
        href="/marker-ofek"
        className="inline-flex w-fit items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowRight className="size-4 rotate-180" aria-hidden />
        חזרה ללוח הבקרה
      </Link>
      <Card className="border-border/70 shadow-sm">
        <CardHeader className="border-b border-border/60">
          <div className="flex items-center gap-3">
            <div className="flex size-11 shrink-0 items-center justify-center rounded-xl border border-violet-500/30 bg-violet-500/10 text-violet-300">
              <CalendarDays className="size-5" aria-hidden />
            </div>
            <div>
              <CardTitle>ניהול פרויקטים וגנט</CardTitle>
              <CardDescription>לוח זמנים ותרשים גנט — מרקר אופק</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <p className="text-sm text-muted-foreground">
            פרויקטים מקושרים לחוזים במסך החוזים. לוח זמנים, משימות ותרשים גנט
            זמינים במסך ייעודי.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button render={<Link href="/marker-ofek/schedule" />}>
              לוחות זמנים וגנט
            </Button>
            <Button variant="outline" render={<Link href="/marker-ofek/contracts" />}>
              מעבר לחוזים
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
