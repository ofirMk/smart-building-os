"use client"

import Link from "next/link"
import { useRouter } from "next/navigation"
import * as React from "react"
import { ArrowRight, Loader2, Package, Plus } from "lucide-react"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { buttonVariants } from "@/components/ui/button-variants"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { createSupabaseBrowserClient } from "@/lib/supabase/browser"
import { cn } from "@/lib/utils"
import type { MarkerOfekItemsCatalogRow } from "@/types/marker-ofek"

const currencyFormatter = new Intl.NumberFormat("he-IL", {
  style: "currency",
  currency: "ILS",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
})

export default function MarkerOfekItemsCatalogPage() {
  const router = useRouter()
  const [rows, setRows] = React.useState<MarkerOfekItemsCatalogRow[]>([])
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState<string | null>(null)
  const [dialogOpen, setDialogOpen] = React.useState(false)
  const [saving, setSaving] = React.useState(false)
  const [form, setForm] = React.useState({
    sku: "",
    description: "",
    unit: "",
    category: "",
    default_price: "",
    is_inventory: false,
  })

  const load = React.useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const supabase = createSupabaseBrowserClient()
      const { data, error: qErr } = await supabase
        .from("items_catalog")
        .select("*")
        .order("sku", { ascending: true })
      if (qErr) throw qErr
      setRows((data as MarkerOfekItemsCatalogRow[]) ?? [])
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    } finally {
      setLoading(false)
    }
  }, [])

  React.useEffect(() => {
    void load()
  }, [load])

  async function handleAddItem(e: React.FormEvent) {
    e.preventDefault()
    const sku = form.sku.trim()
    const description = form.description.trim()
    if (!sku || !description) {
      toast.error("מק״ט מאסטר ותיאור פנימי הם שדות חובה")
      return
    }
    const defaultPriceRaw = form.default_price.trim().replace(",", ".")
    const defaultPrice =
      defaultPriceRaw === "" ? null : parseFloat(defaultPriceRaw)
    if (defaultPriceRaw !== "" && !Number.isFinite(defaultPrice)) {
      toast.error("מחיר ברירת מחדל אינו מספר תקין")
      return
    }

    setSaving(true)
    try {
      const supabase = createSupabaseBrowserClient()
      const { data, error: insErr } = await supabase
        .from("items_catalog")
        .insert({
          sku,
          description,
          unit: form.unit.trim() || null,
          category: form.category.trim() || null,
          default_price: defaultPrice,
          is_inventory: form.is_inventory,
        })
        .select("id")
        .single()
      if (insErr) throw insErr
      toast.success("הפריט נוסף לקטלוג")
      setDialogOpen(false)
      setForm({
        sku: "",
        description: "",
        unit: "",
        category: "",
        default_price: "",
        is_inventory: false,
      })
      await load()
      if (data?.id) router.push(`/marker-ofek/items/${data.id}`)
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : "שמירת הפריט נכשלה"
      )
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-6 pb-12">
      <Link
        href="/marker-ofek"
        className="inline-flex w-fit items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowRight className="size-4 rotate-180" aria-hidden />
        חזרה ללוח מרקר אופק
      </Link>

      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">
            קטלוג פריטים
          </h1>
          <p className="text-sm text-muted-foreground">
            מק״טים פנימיים (מאסטר) לרכש ולניהול ספקים.
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger
            type="button"
            className={cn(buttonVariants(), "gap-2 shrink-0")}
          >
            <Plus className="size-4" aria-hidden />
            הוספת מק״ט פנימי
          </DialogTrigger>
          <DialogContent className="max-w-md" dir="rtl">
            <form onSubmit={(e) => void handleAddItem(e)}>
              <DialogHeader>
                <DialogTitle>פריט חדש בקטלוג</DialogTitle>
                <DialogDescription>
                  מק״ט ייחודי ותיאור פנימי — ישמשו בבחירת פריט בהזמנות רכש.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="new-sku">מק״ט מאסטר</Label>
                  <Input
                    id="new-sku"
                    value={form.sku}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, sku: e.target.value }))
                    }
                    placeholder="למשל MO-CEM-001"
                    dir="ltr"
                    className="font-mono"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-desc">תיאור פנימי</Label>
                  <Input
                    id="new-desc"
                    value={form.description}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, description: e.target.value }))
                    }
                    placeholder="תיאור לשימוש ארגוני"
                    required
                  />
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="new-unit">יחידת מידה</Label>
                    <Input
                      id="new-unit"
                      value={form.unit}
                      onChange={(e) =>
                        setForm((f) => ({ ...f, unit: e.target.value }))
                      }
                      placeholder="מ״ק, יח׳, ק״ג…"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="new-cat">קטגוריה</Label>
                    <Input
                      id="new-cat"
                      value={form.category}
                      onChange={(e) =>
                        setForm((f) => ({ ...f, category: e.target.value }))
                      }
                      placeholder="אופציונלי"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-price">מחיר ברירת מחדל (₪)</Label>
                  <Input
                    id="new-price"
                    type="text"
                    inputMode="decimal"
                    value={form.default_price}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, default_price: e.target.value }))
                    }
                    placeholder="ריק אם אין"
                  />
                </div>
                <label className="flex cursor-pointer items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={form.is_inventory}
                    onChange={(e) =>
                      setForm((f) => ({ ...f, is_inventory: e.target.checked }))
                    }
                    className="size-4 rounded border-input"
                  />
                  פריט מלאי
                </label>
              </div>
              <DialogFooter className="gap-2 sm:gap-0">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                  disabled={saving}
                >
                  ביטול
                </Button>
                <Button type="submit" disabled={saving} className="gap-2">
                  {saving ? (
                    <Loader2 className="size-4 animate-spin" aria-hidden />
                  ) : null}
                  שמירה
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {error ? (
        <p className="text-sm text-destructive">{error}</p>
      ) : null}

      <Card className="border-border/70 shadow-sm">
        <CardHeader className="border-b border-border/60 pb-4">
          <div className="flex items-start gap-3">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-cyan-500/15 text-cyan-700 dark:text-cyan-400">
              <Package className="size-5" aria-hidden />
            </div>
            <div className="space-y-1">
              <CardTitle>רשימת פריטים</CardTitle>
              <CardDescription>
                לחצו על שורה לפתיחת כרטיס מאסטר וניהול ספקים.
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          {loading ? (
            <div className="flex items-center gap-2 py-10 text-muted-foreground">
              <Loader2 className="size-5 animate-spin" aria-hidden />
              טוען קטלוג…
            </div>
          ) : rows.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">
              אין פריטים בקטלוג. הוסיפו מק״ט פנימי חדש.
            </p>
          ) : (
            <div className="overflow-x-auto rounded-lg border border-border/60">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-start">מק״ט מאסטר</TableHead>
                    <TableHead className="text-start">תיאור פנימי</TableHead>
                    <TableHead className="text-start">יחידה</TableHead>
                    <TableHead className="text-start">מחיר ברירת מחדל</TableHead>
                    <TableHead className="text-start">מלאי</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((r) => (
                    <TableRow key={r.id} className="cursor-pointer hover:bg-muted/40">
                      <TableCell className="font-mono text-sm">
                        <Link
                          href={`/marker-ofek/items/${r.id}`}
                          className="text-primary underline-offset-4 hover:underline"
                        >
                          {r.sku}
                        </Link>
                      </TableCell>
                      <TableCell>{r.description}</TableCell>
                      <TableCell>{r.unit?.trim() || "—"}</TableCell>
                      <TableCell className="tabular-nums">
                        {r.default_price != null
                          ? currencyFormatter.format(Number(r.default_price))
                          : "—"}
                      </TableCell>
                      <TableCell>{r.is_inventory ? "כן" : "לא"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
