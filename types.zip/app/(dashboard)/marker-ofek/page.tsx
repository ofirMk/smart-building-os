"use client"

import Link from "next/link"
import * as React from "react"
import {
  ArrowLeft,
  Banknote,
  Building2,
  CalendarDays,
  ClipboardList,
  FileSignature,
  LayoutDashboard,
  Loader2,
  Settings,
  ShoppingCart,
  TrendingDown,
  TrendingUp,
} from "lucide-react"

import { buttonVariants } from "@/components/ui/button-variants"
import { createSupabaseBrowserClient } from "@/lib/supabase/browser"
import { cn } from "@/lib/utils"

const quickLinks = [
  {
    title: "חוזים וחשבונות",
    href: "/marker-ofek/contracts",
    icon: FileSignature,
    description: "חוזים, כתב כמויות והפקת חשבונות חלקיים",
  },
  {
    title: "רכש וספקים",
    href: "/marker-ofek/procurement",
    icon: ShoppingCart,
    description: "הזמנות רכש וקבלות סחורה",
  },
  {
    title: "כספים",
    href: "/marker-ofek/finance",
    icon: Banknote,
    description: "חשבוניות מס וקבלות",
  },
  {
    title: "פרויקטים וגנט",
    href: "/marker-ofek/projects",
    icon: CalendarDays,
    description: "תכנון ומעקב",
  },
  {
    title: "הגדרות חברה",
    href: "/marker-ofek/settings",
    icon: Settings,
    description: "פרטים רשמיים למס ורשויות",
  },
] as const

const currencyFormatter = new Intl.NumberFormat("he-IL", {
  style: "currency",
  currency: "ILS",
  maximumFractionDigits: 0,
})

const dateFormatter = new Intl.DateTimeFormat("he-IL", {
  dateStyle: "short",
  timeStyle: "short",
})

type PartialActivityRow = {
  id: string
  payment_due: number
  created_at: string
  projects:
    | { name: string; internal_project_code: string | null }
    | { name: string; internal_project_code: string | null }[]
    | null
}

type PendingPoRow = {
  id: string
  po_number: string
  status: string
  total_amount: number
  created_at: string
}

function embedOne<T>(x: T | T[] | null | undefined): T | null {
  if (x == null) return null
  return Array.isArray(x) ? (x[0] ?? null) : x
}

function sumMoney(rows: { grand_total?: number }[] | null): number {
  if (!rows?.length) return 0
  return rows.reduce((s, r) => s + (Number(r.grand_total) || 0), 0)
}

function sumPoAmount(rows: { total_amount?: number }[] | null): number {
  if (!rows?.length) return 0
  return rows.reduce((s, r) => s + (Number(r.total_amount) || 0), 0)
}

export default function MarkerOfekDashboardPage() {
  const [loading, setLoading] = React.useState(true)
  const [loadError, setLoadError] = React.useState<string | null>(null)
  const [revenue, setRevenue] = React.useState(0)
  const [expenses, setExpenses] = React.useState(0)
  const [openPoCount, setOpenPoCount] = React.useState(0)
  const [activeProjects, setActiveProjects] = React.useState(0)
  const [recentPartials, setRecentPartials] = React.useState<PartialActivityRow[]>(
    []
  )
  const [pendingPos, setPendingPos] = React.useState<PendingPoRow[]>([])

  React.useEffect(() => {
    let cancelled = false

    async function load() {
      setLoading(true)
      setLoadError(null)
      try {
        const supabase = createSupabaseBrowserClient()

        const [
          revRes,
          expRes,
          openPoHead,
          projHead,
          partialRes,
          pendingPoRes,
        ] = await Promise.all([
          supabase
            .from("mo_invoices")
            .select("grand_total")
            .in("document_type", ["tax_invoice", "tax_invoice_receipt"])
            .neq("status", "cancelled"),
          supabase
            .from("purchase_orders")
            .select("total_amount")
            .eq("is_deleted", false)
            .in("status", ["approved", "closed"]),
          supabase
            .from("purchase_orders")
            .select("id", { count: "exact", head: true })
            .eq("is_deleted", false)
            .in("status", ["approved", "partial_receipt"]),
          supabase
            .from("projects")
            .select("id", { count: "exact", head: true })
            .eq("is_deleted", false)
            .in("status", ["planning", "active", "on_hold"]),
          supabase
            .from("partial_accounts")
            .select(
              `
              id,
              payment_due,
              created_at,
              projects ( name, internal_project_code )
            `
            )
            .eq("is_deleted", false)
            .order("created_at", { ascending: false })
            .limit(5),
          supabase
            .from("purchase_orders")
            .select("id, po_number, status, total_amount, created_at")
            .eq("is_deleted", false)
            .in("status", ["approved", "sent", "partial_receipt"])
            .order("created_at", { ascending: false })
            .limit(5),
        ])

        if (revRes.error && !isMissingRelation(revRes.error.message)) {
          throw revRes.error
        }
        if (expRes.error) throw expRes.error
        if (openPoHead.error) throw openPoHead.error
        if (projHead.error) throw projHead.error
        if (partialRes.error) throw partialRes.error
        if (pendingPoRes.error) throw pendingPoRes.error

        if (!cancelled) {
          setRevenue(
            revRes.error ? 0 : sumMoney(revRes.data as { grand_total: number }[])
          )
          setExpenses(sumPoAmount(expRes.data as { total_amount: number }[]))
          setOpenPoCount(openPoHead.count ?? 0)
          setActiveProjects(projHead.count ?? 0)
          setRecentPartials((partialRes.data as PartialActivityRow[]) ?? [])
          setPendingPos((pendingPoRes.data as PendingPoRow[]) ?? [])
        }
      } catch (e) {
        if (!cancelled) {
          setLoadError(e instanceof Error ? e.message : String(e))
          setRevenue(0)
          setExpenses(0)
          setOpenPoCount(0)
          setActiveProjects(0)
          setRecentPartials([])
          setPendingPos([])
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    void load()
    return () => {
      cancelled = true
    }
  }, [])

  return (
    <div
      dir="rtl"
      lang="he"
      className="flex min-h-0 flex-1 flex-col gap-8 pb-12 sm:gap-10"
    >
      <header className="relative overflow-hidden rounded-2xl border border-border/60 bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950/50 p-6 shadow-xl shadow-black/15 ring-1 ring-white/5 sm:p-8 md:p-10">
        <div
          className="pointer-events-none absolute -start-20 -top-20 size-80 rounded-full bg-indigo-500/15 blur-3xl"
          aria-hidden
        />
        <div className="pointer-events-none absolute bottom-0 end-0 size-56 rounded-full bg-emerald-500/10 blur-3xl" aria-hidden />
        <div className="relative flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
          <div className="flex min-w-0 flex-1 items-start gap-4">
            <div className="flex size-14 shrink-0 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-indigo-200 shadow-inner">
              <LayoutDashboard className="size-7" aria-hidden />
            </div>
            <div className="min-w-0 space-y-2">
              <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-indigo-300/90">
                מרקר אופק
              </p>
              <h1 className="text-pretty text-2xl font-bold tracking-tight text-white sm:text-3xl md:text-4xl">
                לוח בקרה ראשי
              </h1>
              <p className="max-w-2xl text-sm leading-relaxed text-slate-300/95 sm:text-[15px]">
                תמונת מצב כספית ותפעולית — הכנסות, רכש, פרויקטים ופעילות אחרונה.
              </p>
            </div>
          </div>
        </div>
      </header>

      {loadError ? (
        <div
          className="rounded-xl border border-amber-500/35 bg-amber-500/10 px-4 py-3 text-sm text-amber-950 dark:text-amber-100"
          role="alert"
        >
          <p className="font-medium">לא נטענו כל הנתונים</p>
          <p className="mt-1 text-xs opacity-90">{loadError}</p>
          <p className="mt-2 text-xs text-muted-foreground dark:text-amber-200/80">
            ודאו שהרצתם את marker_ofek_finance.sql (mo_invoices) ו-marker_ofek_data_integrity.sql
            (is_deleted).
          </p>
        </div>
      ) : null}

      <section
        className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"
        aria-label="מדדי ביצוע עליונים"
      >
        <KpiCard
          title="סה״כ הכנסות"
          subtitle="חשבונית מס וחשבונית מס קבלה"
          value={loading ? null : currencyFormatter.format(revenue)}
          icon={TrendingUp}
          accent="emerald"
        />
        <KpiCard
          title="הוצאות רכש"
          subtitle="הזמנות מאושרות ונסגרו"
          value={loading ? null : currencyFormatter.format(expenses)}
          icon={TrendingDown}
          accent="rose"
        />
        <KpiCard
          title="הזמנות רכש פתוחות"
          subtitle="מאושרות או קבלה חלקית"
          value={loading ? null : String(openPoCount)}
          icon={ClipboardList}
          accent="sky"
        />
        <KpiCard
          title="פרויקטים פעילים"
          subtitle="תכנון, פעיל או בהמתנה"
          value={loading ? null : String(activeProjects)}
          icon={Building2}
          accent="violet"
        />
      </section>

      <section
        className="grid gap-6 lg:grid-cols-3 lg:gap-8"
        aria-label="פעילות ורכש"
      >
        <div className="flex flex-col gap-4 max-lg:order-2 lg:col-span-2">
          <div className="flex items-center justify-between gap-2 border-b border-border/50 pb-2">
            <h2 className="text-lg font-semibold tracking-tight text-foreground sm:text-xl">
              פעילות אחרונה
            </h2>
            <span className="text-xs font-medium text-muted-foreground">
              חשבונות חלקיים
            </span>
          </div>
          <div className="overflow-hidden rounded-2xl border border-border/60 bg-card/80 shadow-sm ring-1 ring-black/[0.03] backdrop-blur-sm dark:ring-white/[0.04]">
            {loading ? (
              <div className="flex items-center justify-center gap-2 py-16 text-muted-foreground">
                <Loader2 className="size-5 animate-spin" aria-hidden />
                טוען…
              </div>
            ) : recentPartials.length === 0 ? (
              <p className="px-4 py-12 text-center text-sm text-muted-foreground sm:px-6">
                אין עדיין חשבונות חלקיים להצגה.
              </p>
            ) : (
              <ul className="divide-y divide-border/60">
                {recentPartials.map((row) => {
                  const proj = embedOne(row.projects)
                  return (
                    <li
                      key={row.id}
                      className="flex flex-col gap-2 px-4 py-4 transition-colors hover:bg-muted/30 sm:flex-row sm:items-center sm:justify-between sm:px-5"
                    >
                      <div className="min-w-0">
                        <p className="font-medium text-foreground">
                          {proj?.name ?? "פרויקט —"}
                        </p>
                        {proj?.internal_project_code ? (
                          <p className="font-mono text-xs text-muted-foreground">
                            {proj.internal_project_code}
                          </p>
                        ) : null}
                      </div>
                      <div className="flex shrink-0 flex-wrap items-center gap-4 sm:justify-end">
                        <span className="text-lg font-bold tabular-nums text-emerald-700 dark:text-emerald-400">
                          {currencyFormatter.format(Number(row.payment_due) || 0)}
                        </span>
                        <time
                          className="text-xs tabular-nums text-muted-foreground"
                          dateTime={row.created_at}
                        >
                          {dateFormatter.format(new Date(row.created_at))}
                        </time>
                      </div>
                    </li>
                  )
                })}
              </ul>
            )}
          </div>
        </div>

        <div className="order-1 flex flex-col gap-4 max-lg:order-1 lg:col-span-1">
          <div className="flex items-center justify-between gap-2 border-b border-border/50 pb-2">
            <h2 className="text-lg font-semibold tracking-tight text-foreground sm:text-xl">
              רכש ממתין לקבלה
            </h2>
            <span className="text-xs font-medium text-muted-foreground">5 אחרונות</span>
          </div>
          <div className="overflow-hidden rounded-2xl border border-border/60 bg-card/80 shadow-sm ring-1 ring-black/[0.03] backdrop-blur-sm dark:ring-white/[0.04]">
            {loading ? (
              <div className="flex items-center justify-center gap-2 py-16 text-muted-foreground">
                <Loader2 className="size-5 animate-spin" aria-hidden />
                טוען…
              </div>
            ) : pendingPos.length === 0 ? (
              <p className="px-4 py-12 text-center text-sm text-muted-foreground sm:px-6">
                אין הזמנות ממתינות לקבלה.
              </p>
            ) : (
              <ul className="divide-y divide-border/60">
                {pendingPos.map((po) => (
                  <li
                    key={po.id}
                    className="flex flex-col gap-3 px-4 py-4 sm:px-5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-mono text-sm font-semibold text-foreground">
                        {po.po_number}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {currencyFormatter.format(Number(po.total_amount) || 0)}
                      </span>
                    </div>
                    <Link
                      href={`/marker-ofek/procurement/receipt/${po.id}`}
                      className={cn(
                        buttonVariants({ size: "sm", variant: "outline" }),
                        "w-full justify-center gap-2 border-sky-500/40 text-sky-800 hover:bg-sky-500/10 dark:text-sky-300"
                      )}
                    >
                      <ArrowLeft className="size-3.5 rotate-180" aria-hidden />
                      קליטת סחורה
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </section>

      <section aria-label="קיצורי דרך">
        <h2 className="mb-4 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          מודולים
        </h2>
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-5">
          {quickLinks.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                buttonVariants({ variant: "outline", size: "lg" }),
                "h-auto min-h-[6.5rem] flex-col items-stretch justify-between gap-2 border-border/60 bg-card/60 p-4 text-start shadow-sm transition-all hover:-translate-y-0.5 hover:border-indigo-500/30 hover:shadow-md"
              )}
            >
              <div className="flex items-center gap-3">
                <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                  <item.icon className="size-4" aria-hidden />
                </span>
                <span className="font-semibold leading-snug text-foreground">
                  {item.title}
                </span>
              </div>
              <span className="text-[11px] leading-snug text-muted-foreground">
                {item.description}
              </span>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}

function isMissingRelation(msg: string): boolean {
  return (
    msg.includes("relation") ||
    msg.includes("does not exist") ||
    msg.includes("schema cache")
  )
}

const accentMap = {
  emerald: {
    ring: "ring-emerald-500/20",
    iconBg: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-400",
    bar: "from-emerald-500/80 to-emerald-600/40",
  },
  rose: {
    ring: "ring-rose-500/20",
    iconBg: "bg-rose-500/12 text-rose-700 dark:text-rose-400",
    bar: "from-rose-500/80 to-orange-500/40",
  },
  sky: {
    ring: "ring-sky-500/20",
    iconBg: "bg-sky-500/12 text-sky-700 dark:text-sky-400",
    bar: "from-sky-500/80 to-blue-600/40",
  },
  violet: {
    ring: "ring-violet-500/20",
    iconBg: "bg-violet-500/12 text-violet-700 dark:text-violet-400",
    bar: "from-violet-500/80 to-purple-600/40",
  },
} as const

function KpiCard({
  title,
  subtitle,
  value,
  icon: Icon,
  accent,
}: {
  title: string
  subtitle: string
  value: string | null
  icon: React.ComponentType<{ className?: string; "aria-hidden"?: boolean }>
  accent: keyof typeof accentMap
}) {
  const a = accentMap[accent]
  return (
    <article
      className={cn(
        "relative overflow-hidden rounded-2xl border border-border/60 bg-card/90 p-5 shadow-sm ring-1 backdrop-blur-sm transition-shadow hover:shadow-md",
        a.ring
      )}
    >
      <div
        className={cn(
          "pointer-events-none absolute inset-x-0 top-0 h-1 bg-gradient-to-l opacity-90",
          a.bar
        )}
        aria-hidden
      />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 space-y-1">
          <p className="text-[13px] font-semibold text-foreground">{title}</p>
          <p className="text-[11px] leading-snug text-muted-foreground">
            {subtitle}
          </p>
        </div>
        <span
          className={cn(
            "flex size-10 shrink-0 items-center justify-center rounded-xl",
            a.iconBg
          )}
        >
          <Icon className="size-5" aria-hidden />
        </span>
      </div>
      <p className="mt-4 text-2xl font-bold tabular-nums tracking-tight text-foreground sm:text-[1.65rem]">
        {value === null ? (
          <span className="inline-flex items-center gap-2 text-muted-foreground">
            <Loader2 className="size-5 animate-spin" aria-hidden />
          </span>
        ) : (
          value
        )}
      </p>
    </article>
  )
}
