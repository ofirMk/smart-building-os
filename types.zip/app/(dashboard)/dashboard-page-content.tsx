import { DashboardClient } from "@/components/dashboard/DashboardClient"
import {
  loadDashboardShowcase,
  SHOWCASE_MOCK,
} from "@/lib/dashboard-showcase"

export const dynamic = "force-dynamic"

export default async function DashboardPageContent() {
  const vm = await loadDashboardShowcase()

  const data =
    vm.useFallback === true
      ? {
          facilitiesValue: SHOWCASE_MOCK.facilitiesValue,
          facilitiesSub: SHOWCASE_MOCK.facilitiesSub,
          openTicketsValue: SHOWCASE_MOCK.openTicketsValue,
          openTicketsSub: SHOWCASE_MOCK.openTicketsSub,
          energyValue: SHOWCASE_MOCK.energyValue,
          energySub: SHOWCASE_MOCK.energySub,
          slaValue: SHOWCASE_MOCK.slaValue,
          slaSub: SHOWCASE_MOCK.slaSub,
          powerHeightsPct: [...SHOWCASE_MOCK.powerHeightsPct],
          powerLabels: [...SHOWCASE_MOCK.powerLabels],
          buildingRows: SHOWCASE_MOCK.buildingRows.map((r) => ({ ...r })),
        }
      : {
          facilitiesValue: vm.facilitiesValue,
          facilitiesSub: vm.facilitiesSub,
          openTicketsValue: vm.openTicketsValue,
          openTicketsSub: vm.openTicketsSub,
          energyValue: vm.energyValue,
          energySub: vm.energySub,
          slaValue: vm.slaValue,
          slaSub: vm.slaSub,
          powerHeightsPct: vm.powerHeightsPct,
          powerLabels: vm.powerLabels,
          buildingRows: vm.buildingRows.map((r) => ({ ...r })),
        }

  return <DashboardClient data={data} />
}
