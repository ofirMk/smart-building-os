export default function DashboardLoading() {
  return (
    <div
      className="-mx-4 min-h-[calc(100vh-3.5rem)] bg-[#0a0a0a] px-4 py-6 md:-mx-6 md:px-6 md:py-10"
      dir="rtl"
    >
      <header className="mb-10 border-b border-gray-800 pb-6">
        <div className="mb-2 h-9 w-3/4 max-w-md animate-pulse rounded-lg bg-gray-800 md:h-11" />
        <div className="h-4 w-2/3 max-w-lg animate-pulse rounded bg-gray-800/80" />
      </header>

      <div className="mb-10 grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div
            key={i}
            className="relative overflow-hidden rounded-2xl border border-gray-800 bg-[#111111] p-6 shadow-lg"
          >
            <div className="absolute end-0 top-0 h-full w-1 animate-pulse bg-gray-700" />
            <div className="mb-2 h-4 w-28 animate-pulse rounded bg-gray-800" />
            <div className="mb-2 h-9 w-20 animate-pulse rounded bg-gray-800" />
            <div className="h-3 w-full max-w-[12rem] animate-pulse rounded bg-gray-800/70" />
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-gray-800 bg-[#111111] p-6 shadow-lg">
          <div className="mb-6 flex items-center gap-2">
            <span className="inline-block h-6 w-2 animate-pulse rounded-full bg-gray-700" />
            <div className="h-6 w-48 animate-pulse rounded bg-gray-800" />
          </div>
          <div className="flex h-48 items-end gap-3 pt-4 md:gap-6">
            {Array.from({ length: 7 }).map((_, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-2">
                <div
                  className="w-full animate-pulse rounded-t-sm bg-gray-800"
                  style={{ height: `${30 + (i % 4) * 12}%` }}
                />
                <div className="h-3 w-8 animate-pulse rounded bg-gray-800/80" />
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-2xl border border-gray-800 bg-[#111111] p-6 shadow-lg">
          <div className="mb-6 flex items-center gap-2">
            <span className="inline-block h-6 w-2 animate-pulse rounded-full bg-gray-700" />
            <div className="h-6 w-40 animate-pulse rounded bg-gray-800" />
          </div>
          <div className="space-y-4 pt-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i}>
                <div className="mb-1 flex justify-between">
                  <div className="h-4 w-24 animate-pulse rounded bg-gray-800" />
                  <div className="h-4 w-10 animate-pulse rounded bg-gray-800" />
                </div>
                <div className="h-2.5 w-full animate-pulse rounded-full bg-gray-800" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
