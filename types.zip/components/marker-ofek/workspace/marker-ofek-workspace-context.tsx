"use client"

import * as React from "react"
import { usePathname } from "next/navigation"

const MAX_RECENT_TABS = 3

export type MarkerOfekRecentTab = {
  href: string
  label: string
}

function tabLabelForPath(pathname: string): string {
  if (pathname === "/marker-ofek" || pathname === "/marker-ofek/")
    return "לוח בקרה"
  if (pathname.startsWith("/marker-ofek/contracts/new")) return "חוזה חדש"
  if (pathname.startsWith("/marker-ofek/contracts/") && pathname !== "/marker-ofek/contracts")
    return "פרטי חוזה"
  if (pathname === "/marker-ofek/contracts") return "חוזים"
  if (pathname.startsWith("/marker-ofek/procurement/new")) return "הזמנת רכש חדשה"
  if (pathname.startsWith("/marker-ofek/procurement/receipt/")) return "קבלת סחורה"
  if (pathname.startsWith("/marker-ofek/procurement/") && pathname !== "/marker-ofek/procurement")
    return "הזמנת רכש"
  if (pathname === "/marker-ofek/procurement") return "רכש"
  if (pathname.startsWith("/marker-ofek/schedule")) return "לוח זמנים"
  if (pathname.startsWith("/marker-ofek/budget")) return "תקציב"
  if (pathname.startsWith("/marker-ofek/items")) return "קטלוג"
  if (pathname.startsWith("/marker-ofek/finance")) return "כספים"
  if (pathname.startsWith("/marker-ofek/settings")) return "הגדרות"
  return "מרקר אופק"
}

type MarkerOfekWorkspaceContextValue = {
  recentTabs: MarkerOfekRecentTab[]
  contextProjectId: string | null
  setContextProjectId: (id: string | null) => void
  commandPaletteOpen: boolean
  setCommandPaletteOpen: (open: boolean) => void
  projectDrawerOpen: boolean
  setProjectDrawerOpen: (open: boolean) => void
  openCommandPalette: () => void
  openProjectDrawer: () => void
}

const MarkerOfekWorkspaceContext =
  React.createContext<MarkerOfekWorkspaceContextValue | null>(null)

export function MarkerOfekWorkspaceProvider({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname() ?? ""
  const [recentTabs, setRecentTabs] = React.useState<MarkerOfekRecentTab[]>([])
  const [contextProjectId, setContextProjectId] = React.useState<string | null>(
    null
  )
  const [commandPaletteOpen, setCommandPaletteOpen] = React.useState(false)
  const [projectDrawerOpen, setProjectDrawerOpen] = React.useState(false)

  const lastRecorded = React.useRef<string>("")

  React.useEffect(() => {
    if (!pathname.startsWith("/marker-ofek")) return
    if (pathname === lastRecorded.current) return
    lastRecorded.current = pathname

    const label = tabLabelForPath(pathname)
    setRecentTabs((prev) => {
      const next = prev.filter((t) => t.href !== pathname)
      next.unshift({ href: pathname, label })
      return next.slice(0, MAX_RECENT_TABS)
    })
  }, [pathname])

  const openCommandPalette = React.useCallback(() => {
    setCommandPaletteOpen(true)
  }, [])

  const openProjectDrawer = React.useCallback(() => {
    setProjectDrawerOpen(true)
  }, [])

  const value = React.useMemo(
    () => ({
      recentTabs,
      contextProjectId,
      setContextProjectId,
      commandPaletteOpen,
      setCommandPaletteOpen,
      projectDrawerOpen,
      setProjectDrawerOpen,
      openCommandPalette,
      openProjectDrawer,
    }),
    [
      recentTabs,
      contextProjectId,
      commandPaletteOpen,
      projectDrawerOpen,
      openCommandPalette,
      openProjectDrawer,
    ]
  )

  return (
    <MarkerOfekWorkspaceContext.Provider value={value}>
      {children}
    </MarkerOfekWorkspaceContext.Provider>
  )
}

export function useMarkerOfekWorkspace() {
  const ctx = React.useContext(MarkerOfekWorkspaceContext)
  if (!ctx) {
    throw new Error(
      "useMarkerOfekWorkspace must be used within MarkerOfekWorkspaceProvider"
    )
  }
  return ctx
}

export function useMarkerOfekWorkspaceOptional() {
  return React.useContext(MarkerOfekWorkspaceContext)
}
