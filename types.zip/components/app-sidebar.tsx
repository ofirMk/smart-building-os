"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useEffect, useMemo, useState, useTransition } from "react"
import {
  ArrowRightLeft,
  CalendarDays,
  CalendarRange,
  ChevronUp,
  FileSignature,
  Gauge,
  LayoutGrid,
  LogOut,
  Megaphone,
  MessageSquare,
  Scale,
  Settings,
  ShoppingCart,
  Tags,
  Ticket,
  Users,
  LayoutDashboard,
  Banknote,
} from "lucide-react"

import { logout } from "@/app/(dashboard)/actions"
import {
  type AppUserRole,
  guyRahumimWelcomeMessage,
} from "@/lib/auth/user-role"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  SidebarSeparator,
  useSidebar,
} from "@/components/ui/sidebar"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { createSupabaseBrowserClient } from "@/lib/supabase/browser"
import { cn } from "@/lib/utils"

const tenantLinks = [
  { title: "לוח בקרה", href: "/dashboard", icon: LayoutDashboard },
  { title: "צ'אט AI", href: "/chat", icon: MessageSquare },
  { title: "מרכז הכרזות", href: "/announcements", icon: Megaphone },
  { title: "קריאות שירות", href: "/tickets", icon: Ticket },
  { title: "מתקנים", href: "/amenities", icon: CalendarDays },
] as const

/** ERP subset shown on the facility shell for admins (full list under /marker-ofek). */
const MARKER_OFEK_ERP_HREFS = new Set([
  "/marker-ofek",
  "/marker-ofek/contracts",
  "/marker-ofek/finance",
  "/marker-ofek/budget",
  "/marker-ofek/procurement",
  "/marker-ofek/schedule",
])

const markerOfekLinks = [
  { title: "לוח בקרה", href: "/marker-ofek", icon: LayoutDashboard },
  {
    title: "חוזים וחשבונות",
    href: "/marker-ofek/contracts",
    icon: FileSignature,
  },
  {
    title: "כספים — חשבוניות",
    href: "/marker-ofek/finance",
    icon: Banknote,
  },
  {
    title: "בקרה תקציבית",
    href: "/marker-ofek/budget",
    icon: Gauge,
  },
  {
    title: "רכש וספקים",
    href: "/marker-ofek/procurement",
    icon: ShoppingCart,
  },
  {
    title: "גילון ספקים",
    href: "/marker-ofek/procurement/aging",
    icon: Scale,
  },
  {
    title: "קטלוג פריטים",
    href: "/marker-ofek/items",
    icon: Tags,
  },
  {
    title: "ניהול פרויקטים וגנט",
    href: "/marker-ofek/projects",
    icon: CalendarDays,
  },
  {
    title: "לוחות זמנים וגנט",
    href: "/marker-ofek/schedule",
    icon: CalendarRange,
  },
  { title: "הגדרות חברה", href: "/marker-ofek/settings", icon: Settings },
  {
    title: "חזרה לפורטל אחזקה",
    href: "/",
    icon: ArrowRightLeft,
  },
] as const

const markerOfekErpNavForAdmin = markerOfekLinks
  .filter((l) => MARKER_OFEK_ERP_HREFS.has(l.href))
  .map((l) =>
    l.href === "/marker-ofek" ? { ...l, title: "מרקר אופק" as const } : l
  )

const adminLinks = [
  ...tenantLinks,
  { title: "ניהול דיירים", href: "/tenants", icon: Users },
  { title: "הגדרות פרויקט", href: "/settings", icon: Settings },
  ...markerOfekErpNavForAdmin,
  { title: "חזרה לפורטל הולדן", href: "/portal", icon: LayoutGrid },
] as const

function isActivePath(pathname: string, href: string) {
  if (href === "/dashboard") {
    return pathname === "/" || pathname === "/dashboard"
  }
  if (href === "/marker-ofek") {
    return pathname === "/marker-ofek" || pathname === "/marker-ofek/"
  }
  if (href === "/") {
    return pathname === "/" || pathname === "/dashboard"
  }
  return pathname === href || pathname.startsWith(`${href}/`)
}

function avatarLetterFromEmail(email: string | null): string {
  if (!email?.trim()) return "?"
  const first = email.trim().charAt(0)
  return /[a-z]/i.test(first) ? first.toUpperCase() : first
}

type AppSidebarProps = {
  userEmail: string | null
  userRole: AppUserRole
}

export function AppSidebar({ userEmail, userRole }: AppSidebarProps) {
  const pathname = usePathname()
  const [logoutPending, startLogoutTransition] = useTransition()
  const { isMobile, setOpenMobile } = useSidebar()
  const [fetchedRole, setFetchedRole] = useState<
    AppUserRole | null | undefined
  >(undefined)
  const [roleFetchError, setRoleFetchError] = useState<string | null>(null)

  const effectiveRole: AppUserRole = useMemo(
    () =>
      fetchedRole === undefined ? userRole : (fetchedRole ?? userRole),
    [fetchedRole, userRole]
  )

  const isMarkerOfek = pathname.startsWith("/marker-ofek")

  const visibleNav = useMemo(() => {
    if (isMarkerOfek) return markerOfekLinks
    return effectiveRole === "admin" ? adminLinks : tenantLinks
  }, [effectiveRole, isMarkerOfek])

  const guyWelcome = useMemo(
    () => guyRahumimWelcomeMessage(userEmail),
    [userEmail]
  )

  const closeMobileNav = () => {
    if (isMobile) setOpenMobile(false)
  }

  useEffect(() => {
    if (isMobile) setOpenMobile(false)
  }, [pathname, isMobile, setOpenMobile])

  useEffect(() => {
    let isMounted = true

    async function fetchRoleNoCache() {
      try {
        setRoleFetchError(null)
        const supabase = createSupabaseBrowserClient()
        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser()

        if (userError) throw userError

        if (!user) {
          if (!isMounted) return
          setFetchedRole(null)
          return
        }

        const { data: profile, error: profileError } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", user.id)
          .maybeSingle()

        if (profileError) throw profileError

        if (!isMounted) return
        const r = (profile as { role?: AppUserRole } | null)?.role ?? null
        setFetchedRole(r)
      } catch (error) {
        if (!isMounted) return
        setFetchedRole(null)
        setRoleFetchError(error instanceof Error ? error.message : String(error))
      }
    }

    void fetchRoleNoCache()

    return () => {
      isMounted = false
    }
  }, [pathname])

  return (
    <Sidebar
      side="right"
      collapsible="icon"
      variant="inset"
      className="print:hidden"
    >
      <SidebarHeader className="border-b border-sidebar-border/60 pb-3">
        <Link
          href={isMarkerOfek ? "/marker-ofek" : "/"}
          onClick={closeMobileNav}
          className="flex items-center gap-3 rounded-lg px-2 py-1.5 outline-none ring-sidebar-ring transition-colors hover:bg-sidebar-accent focus-visible:ring-2"
        >
          <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground shadow-sm">
            <Gauge className="size-4" aria-hidden />
          </div>
          <div className="flex min-w-0 flex-1 flex-col gap-0.5 group-data-[collapsible=icon]:hidden">
            <span className="truncate text-sm font-semibold tracking-tight">
              {isMarkerOfek ? "מרקר אופק" : "בניין חכם"}
            </span>
            <span className="truncate text-xs text-muted-foreground">
              {isMarkerOfek
                ? "ביצוע, חוזים ורכש"
                : "מרכז פיקוח נכסים"}
            </span>
          </div>
        </Link>
        {guyWelcome ? (
          <p
            className="mt-2 px-2 text-xs font-medium text-emerald-600 group-data-[collapsible=icon]:hidden dark:text-emerald-400"
            data-testid="welcome-guy-rahumim"
          >
            {guyWelcome}
          </p>
        ) : null}
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>
            {isMarkerOfek ? "מרקר אופק" : "תפעול"}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {visibleNav.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton
                    isActive={isActivePath(pathname, item.href)}
                    tooltip={item.title}
                    className={cn(
                      "transition-[box-shadow,background-color,border-color] duration-300",
                      "data-active:border data-active:border-cyan-500/35 data-active:bg-sidebar-accent/90",
                      "data-active:shadow-[0_0_22px_rgba(6,182,212,0.22)] data-active:ring-1 data-active:ring-cyan-400/30"
                    )}
                    render={
                      <Link href={item.href} onClick={closeMobileNav}>
                        <item.icon />
                        <span>{item.title}</span>
                      </Link>
                    }
                  />
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarSeparator />
      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger
                className={cn(
                  "flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-start outline-none ring-sidebar-ring",
                  "hover:bg-sidebar-accent focus-visible:ring-2 data-[popup-open]:bg-sidebar-accent"
                )}
                title={userEmail ?? "חשבון משתמש"}
              >
                <Avatar className="size-8 shrink-0 border border-sidebar-border">
                  <AvatarFallback className="bg-sidebar-accent text-xs font-medium">
                    {avatarLetterFromEmail(userEmail)}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1 group-data-[collapsible=icon]:hidden">
                  <p className="truncate text-sm font-medium">
                    {userEmail ?? "לא זמין"}
                  </p>
                  <p className="mt-1 inline-flex max-w-full rounded-md border border-red-400/90 bg-red-500/30 px-1.5 py-0.5 text-[10px] font-semibold text-red-100">
                    {roleFetchError
                      ? `[Debug Role Error: ${roleFetchError}]`
                      : `[Debug Role: ${effectiveRole}${fetchedRole === undefined ? " (ssr)" : ""}]`}
                  </p>
                  <p className="truncate text-xs text-muted-foreground">
                    מחובר למערכת
                  </p>
                </div>
                <ChevronUp
                  className="size-4 shrink-0 opacity-50 group-data-[collapsible=icon]:hidden"
                  aria-hidden
                />
              </DropdownMenuTrigger>
              <DropdownMenuContent
                className="min-w-56"
                side="top"
                align="end"
                sideOffset={6}
              >
                <DropdownMenuGroup>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col gap-0.5 text-start">
                      <span className="text-sm font-medium">חשבון משתמש</span>
                      <span className="truncate text-xs text-muted-foreground">
                        {userEmail ?? "—"}
                      </span>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    variant="destructive"
                    disabled={logoutPending}
                    onClick={() =>
                      startLogoutTransition(() => {
                        void logout()
                      })
                    }
                  >
                    <LogOut className="size-4" aria-hidden />
                    {logoutPending ? "מתנתקים…" : "התנתקות"}
                  </DropdownMenuItem>
                </DropdownMenuGroup>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
