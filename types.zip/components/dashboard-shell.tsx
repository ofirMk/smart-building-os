"use client"

import { useMemo } from "react"
import { usePathname } from "next/navigation"

import { CommentNotificationBell } from "@/components/dashboard/comment-notification-bell"
import { AppSidebar } from "@/components/app-sidebar"
import { Separator } from "@/components/ui/separator"
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import {
  type AppUserRole,
  guyRahumimWelcomeMessage,
} from "@/lib/auth/user-role"
import { cn } from "@/lib/utils"

const titles: Record<string, string> = {
  "/": "לוח בקרה",
  "/dashboard": "לוח בקרה",
  "/announcements": "מרכז הכרזות",
  "/buildings": "בניינים",
  "/tenants": "ניהול דיירים",
  "/vendors": "ניהול קבלנים",
  "/maintenance": "תחזוקה מונעת",
  "/billing": "ניהול כספים",
  "/documents": "כספת מסמכים",
  "/tickets": "קריאות שירות",
  "/ev-management": "ניהול טעינה",
  "/amenities": "מתקנים",
  "/chat": "צ'אט AI",
}

function titleForPath(pathname: string) {
  if (titles[pathname]) return titles[pathname]
  const match = Object.keys(titles).find(
    (k) => k !== "/" && k !== "/dashboard" && pathname.startsWith(k)
  )
  return match ? titles[match] : "בניין חכם"
}

export function DashboardShell({
  children,
  userEmail,
  userRole,
}: {
  children: React.ReactNode
  userEmail: string | null
  userRole: AppUserRole
}) {
  const pathname = usePathname()
  const title = useMemo(() => titleForPath(pathname), [pathname])
  const headerSubtitle = useMemo(
    () =>
      guyRahumimWelcomeMessage(userEmail) ??
      "תפעול נכסים ברמה הגבוהה ביותר וחוויית דיירים",
    [userEmail]
  )

  return (
    <SidebarProvider>
      <AppSidebar userEmail={userEmail} userRole={userRole} />
      <SidebarInset
        className={cn(
          "relative z-0 min-w-0 flex-1 overflow-x-hidden bg-background",
          /* Desktop `lg+`: reserve space next to fixed sidebar (peer = desktop sidebar column). */
          "lg:pr-64 lg:peer-data-[state=collapsed]:pr-[calc(var(--sidebar-width-icon)+1rem)]",
          "print:pe-0 print:lg:pe-0"
        )}
      >
        <header className="sticky top-0 z-20 flex h-14 shrink-0 items-center gap-2 border-b border-border/60 bg-background/80 px-4 backdrop-blur-md supports-[backdrop-filter]:bg-background/60 print:hidden md:px-6">
          <SidebarTrigger className="-ms-1" />
          <Separator orientation="vertical" className="me-2 h-6" />
          <div className="flex min-w-0 flex-1 flex-col text-start">
            <h1 className="truncate text-lg font-semibold tracking-tight">
              {title}
            </h1>
            <p className="hidden text-xs text-muted-foreground sm:block">
              {headerSubtitle}
            </p>
          </div>
          {userRole === "admin" ? (
            <CommentNotificationBell className="text-muted-foreground hover:text-foreground" />
          ) : null}
        </header>
        <div className="flex min-h-0 flex-1 flex-col gap-6 p-4 print:p-0 md:p-6">
          {children}
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
