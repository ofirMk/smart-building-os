/**
 * Marker Ofek — חוזים (מיפוי לטבלאות Supabase: entities, projects, contracts, contract_line_items)
 *
 * מחיקה רכה (is_deleted, deleted_at) בטבלאות ליבה: projects, entities, contracts,
 * purchase_orders, partial_accounts — ראו marker_ofek_data_integrity.sql. בשאילתות UI יש לסנן
 * `.eq("is_deleted", false)`.
 */

export type MoEntityType = "client" | "subcontractor" | "supplier"

export type MoContractType = "main_contract" | "sub_contract"

export type MoProjectStatus =
  | "planning"
  | "active"
  | "on_hold"
  | "completed"
  | "cancelled"

/** public.mo_project_task_status — משימות בלוח זמנים */
export type MoProjectTaskStatus =
  | "todo"
  | "in_progress"
  | "done"
  | "delayed"

export type MoContractStatus = "draft" | "active" | "closed" | "terminated"

/** public.mo_comment_context — הערות הקשר */
export type MoCommentContext = "contract_item" | "po_line" | "general"

/** public.project_comments */
export type MarkerOfekProjectCommentRow = {
  id: string
  project_id: string
  user_id: string
  context_type: MoCommentContext
  context_id: string | null
  context_label: string | null
  message: string
  created_at: string
}

export type MoPartialAccountStatus =
  | "draft"
  | "submitted"
  | "approved"
  | "paid"

/** public.contract_line_items — סטטוס הוראת שינוי (חריג) */
export type MoChangeOrderStatus = "pending" | "approved" | "rejected"

/** public.mo_invoice_document_type */
export type MoInvoiceDocumentType =
  | "tax_invoice"
  | "receipt"
  | "tax_invoice_receipt"

/** public.mo_invoice_financial_status */
export type MoInvoiceFinancialStatus = "issued" | "paid" | "cancelled"

/** public.mo_receipt_payment_method */
export type MoReceiptPaymentMethod =
  | "bank_transfer"
  | "check"
  | "credit_card"
  | "cash"

/** public.mo_invoices — חשבוניות מס / קבלות (לא public.invoices לדיירים) */
export type MarkerOfekMoInvoiceRow = {
  id: string
  invoice_number: number
  project_id: string
  entity_id: string
  contract_id: string | null
  linked_partial_account_id: string | null
  issue_date: string
  document_type: MoInvoiceDocumentType
  subtotal: number
  vat_amount: number
  grand_total: number
  status: MoInvoiceFinancialStatus
  is_printed_original: boolean
  created_at: string
}

/** public.mo_receipt_payments */
export type MarkerOfekMoReceiptPaymentRow = {
  id: string
  invoice_id: string
  payment_method: MoReceiptPaymentMethod
  reference_number: string | null
  amount: number
  payment_date: string
  created_at: string
}

/** public.company_profile — פרטי מנפיק רשמיים (מע״מ / רשויות מס) */
export interface CompanyProfile {
  id: string
  company_name: string
  legal_id: string | null
  address: string | null
  phone: string | null
  email: string | null
  deductions_file_number: string | null
  created_at: string
}

/** public.entities */
export type MarkerOfekEntityRow = {
  id: string
  name: string
  type: MoEntityType
  company_id: string | null
  contact_info: Record<string, unknown>
  /** ח.פ / ע.מ */
  legal_id: string | null
  address: string | null
  /** תיק ניכויים */
  deductions_file_number: string | null
  /** מספר סידורי מרצף supplier_seq / contractor_seq */
  mo_entity_code: string | null
  is_deleted: boolean
  deleted_at: string | null
  created_at: string
}

/** Alias for ERP / tax documents */
export type Entity = MarkerOfekEntityRow

/** public.projects */
export type MarkerOfekProjectRow = {
  id: string
  internal_project_code: string
  name: string
  address: string | null
  status: MoProjectStatus
  is_deleted: boolean
  deleted_at: string | null
  created_at: string
}

/** public.project_tasks — משימות לגנט */
export type MarkerOfekProjectTaskRow = {
  id: string
  project_id: string
  title: string
  description: string | null
  start_date: string
  end_date: string
  progress: number
  status: MoProjectTaskStatus
  assigned_to: string | null
  created_at: string
}

/** public.contracts */
export type MarkerOfekContractRow = {
  id: string
  project_id: string
  entity_id: string
  contract_type: MoContractType
  parent_contract_id: string | null
  agreement_type: string | null
  retention_pct: number
  insurance_pct: number
  total_amount: number | null
  start_date: string | null
  end_date: string | null
  status: MoContractStatus
  is_deleted: boolean
  deleted_at: string | null
  created_at: string
}

/** public.contract_line_items */
export type MarkerOfekContractLineItemRow = {
  id: string
  contract_id: string
  section_number: string
  description: string
  unit: string | null
  quantity: number | null
  unit_price: number | null
  is_change_order: boolean
  change_order_desc: string | null
  /** original | extra_work | tenant_change */
  line_kind?: string | null
  apartment_number?: string | null
  tenant_change_status?: string | null
  change_order_status?: string | null
  tenant_floor?: string | null
  created_at: string
}

/** טיוטת יצירה / טופס — לפני הכנסה ל-DB */
export type MarkerOfekEntityInsert = {
  name: string
  type: MoEntityType
  company_id?: string | null
  contact_info?: Record<string, unknown>
  legal_id?: string | null
  address?: string | null
  deductions_file_number?: string | null
}

export type MarkerOfekProjectInsert = {
  /** ריק — DB ימלא מ-project_seq (PR-YY-NNNN) */
  internal_project_code?: string
  name: string
  address?: string | null
  status?: MoProjectStatus
}

export type MarkerOfekContractInsert = {
  project_id: string
  entity_id: string
  contract_type: MoContractType
  parent_contract_id?: string | null
  agreement_type?: string | null
  retention_pct?: number
  insurance_pct?: number
  total_amount?: number | null
  start_date?: string | null
  end_date?: string | null
  status?: MoContractStatus
}

export type MarkerOfekContractLineItemInsert = {
  contract_id: string
  section_number: string
  description: string
  unit?: string | null
  quantity?: number | null
  unit_price?: number | null
  is_change_order?: boolean
  change_order_desc?: string | null
  line_kind?: string | null
  apartment_number?: string | null
  tenant_change_status?: string | null
  change_order_status?: string | null
  tenant_floor?: string | null
}

/** public.partial_accounts */
export type MarkerOfekPartialAccountRow = {
  id: string
  contract_id: string
  account_number: number
  status: MoPartialAccountStatus
  total_cumulative_amount: number
  retention_deduction: number
  insurance_deduction: number
  payment_due: number
  snapshot_payload?: Record<string, unknown> | null
  previous_cumulative_approved?: number | null
  project_id?: string | null
  is_deleted: boolean
  deleted_at: string | null
  created_at: string
}

/** public.partial_account_line_items */
export type MarkerOfekPartialAccountLineItemRow = {
  id: string
  partial_account_id: string
  contract_line_item_id: string
  execution_percentage: number
  cumulative_amount: number
  submitted_percentage: number
  submitted_amount: number
  approved_percentage: number
  approved_amount: number
  created_at: string
}

export type MarkerOfekPartialAccountInsert = {
  contract_id: string
  /** אם null — מספר חשבון אוטומטי לפי חוזה (טריגר ב-DB) */
  account_number?: number | null
  status?: MoPartialAccountStatus
  total_cumulative_amount: number
  retention_deduction: number
  insurance_deduction: number
  payment_due: number
  snapshot_payload?: Record<string, unknown> | null
  previous_cumulative_approved?: number | null
  project_id?: string | null
}

export type MarkerOfekPartialAccountLineItemInsert = {
  partial_account_id: string
  contract_line_item_id: string
  execution_percentage: number
  cumulative_amount: number
  submitted_percentage: number
  submitted_amount: number
  approved_percentage: number
  approved_amount: number
}

/** public.mo_po_status */
export type MoPurchaseOrderStatus =
  | "draft"
  | "approved"
  | "sent"
  | "partial_receipt"
  | "closed"

/** public.items_catalog */
export type MarkerOfekItemsCatalogRow = {
  id: string
  sku: string
  description: string
  unit: string | null
  category: string | null
  default_price: number | null
  is_inventory: boolean
  created_at: string
}

/** public.purchase_orders */
export type MarkerOfekPurchaseOrderRow = {
  id: string
  project_id: string
  supplier_id: string
  po_number: string
  status: MoPurchaseOrderStatus
  is_deleted: boolean
  deleted_at: string | null
  order_date: string
  expected_delivery_date: string | null
  internal_notes: string | null
  total_amount: number
  created_at: string
}

/** public.supplier_items — קישור קטלוג ↔ ספק */
export type MarkerOfekSupplierItemRow = {
  id: string
  master_item_id: string
  supplier_id: string
  supplier_sku: string | null
  unit_price: number
  discount_pct: number
  last_updated: string
  is_preferred: boolean
}

/** public.po_line_items */
export type MarkerOfekPoLineItemRow = {
  id: string
  po_id: string
  item_id: string | null
  description: string
  quantity: number
  unit: string | null
  unit_price: number
  total_price: number
  /** הצעה זוכה מ-supplier_items */
  selected_supplier_item_id: string | null
  created_at: string
}

/** public.mo_supplier_invoice_status */
export type MoSupplierInvoiceStatus = "pending" | "paid"

/** public.mo_supplier_invoices */
export type MarkerOfekSupplierInvoiceRow = {
  id: string
  supplier_id: string
  po_id: string
  invoice_number: string | null
  amount: number
  status: MoSupplierInvoiceStatus
  invoice_date: string
  paid_at: string | null
  notes: string | null
  created_at: string
}

/** public.goods_receipts */
export type MarkerOfekGoodsReceiptRow = {
  id: string
  po_id: string
  receipt_date: string
  delivery_note_number: string | null
  received_by: string | null
  delivery_note_image_url: string | null
  shortage_notes: string | null
  created_at: string
}

export type MarkerOfekItemsCatalogInsert = {
  sku: string
  description: string
  unit?: string | null
  category?: string | null
  default_price?: number | null
  is_inventory?: boolean
}

export type MarkerOfekPurchaseOrderInsert = {
  project_id: string
  supplier_id: string
  po_number?: string | null
  status?: MoPurchaseOrderStatus
  order_date?: string
  expected_delivery_date?: string | null
  internal_notes?: string | null
  total_amount?: number
}

export type MarkerOfekSupplierItemInsert = {
  master_item_id: string
  supplier_id: string
  supplier_sku?: string | null
  unit_price?: number
  discount_pct?: number
  is_preferred?: boolean
}

export type MarkerOfekPoLineItemInsert = {
  po_id: string
  item_id?: string | null
  description: string
  quantity: number
  unit?: string | null
  unit_price: number
  total_price: number
  selected_supplier_item_id?: string | null
}

export type MarkerOfekGoodsReceiptInsert = {
  po_id: string
  receipt_date?: string
  delivery_note_number?: string | null
  received_by?: string | null
  delivery_note_image_url?: string | null
  shortage_notes?: string | null
}

export type MarkerOfekSupplierInvoiceInsert = {
  supplier_id: string
  po_id: string
  invoice_number?: string | null
  amount: number
  status?: MoSupplierInvoiceStatus
  invoice_date?: string
  paid_at?: string | null
  notes?: string | null
}

/** public.goods_receipt_items */
export type MarkerOfekGoodsReceiptItemRow = {
  id: string
  goods_receipt_id: string
  po_line_item_id: string
  quantity_received: number
  created_at: string
}

export type MarkerOfekGoodsReceiptItemInsert = {
  goods_receipt_id: string
  po_line_item_id: string
  quantity_received: number
}
